-- phpMyAdmin SQL Dump
-- version 3.1.2
-- http://www.phpmyadmin.net
--
-- Host: multivac
-- Generation Time: Sep 21, 2009 at 01:48 PM
-- Server version: 5.0.70
-- PHP Version: 5.2.6-1+lenny3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sopac`
--

-- --------------------------------------------------------

--
-- Table structure for table `bisac_bibs`
--

CREATE TABLE IF NOT EXISTS `bisac_bibs` (
  `id` int(11) NOT NULL auto_increment,
  `bnum` mediumint(13) NOT NULL,
  `bisac_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `bnum` (`bnum`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=185622 ;

-- --------------------------------------------------------

--
-- Table structure for table `bisac_codes`
--

CREATE TABLE IF NOT EXISTS `bisac_codes` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(256) NOT NULL,
  `display` varchar(256) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2921 ;

-- --------------------------------------------------------

--
-- Table structure for table `insurge_index`
--

CREATE TABLE IF NOT EXISTS `insurge_index` (
  `bnum` varchar(12) NOT NULL,
  `rating_idx` int(8) NOT NULL default '0',
  `tag_idx` mediumtext,
  `review_idx` mediumtext,
  PRIMARY KEY  (`bnum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `insurge_ratings`
--

CREATE TABLE IF NOT EXISTS `insurge_ratings` (
  `rate_id` int(12) NOT NULL auto_increment,
  `repos_id` char(24) default NULL,
  `group_id` char(12) default NULL,
  `uid` varchar(12) default NULL,
  `bnum` int(12) NOT NULL,
  `rating` float NOT NULL,
  `rate_date` datetime NOT NULL,
  PRIMARY KEY  (`rate_id`),
  KEY `repos_id` (`repos_id`),
  KEY `uid` (`uid`),
  KEY `bnum` (`bnum`),
  KEY `rating` (`rating`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1805 ;

-- --------------------------------------------------------

--
-- Table structure for table `insurge_ratings_seq`
--

CREATE TABLE IF NOT EXISTS `insurge_ratings_seq` (
  `sequence` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`sequence`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1805 ;

-- --------------------------------------------------------

--
-- Table structure for table `insurge_reviews`
--

CREATE TABLE IF NOT EXISTS `insurge_reviews` (
  `rev_id` int(12) NOT NULL,
  `repos_id` char(24) default NULL,
  `group_id` char(12) default NULL,
  `uid` varchar(12) default NULL,
  `bnum` int(12) NOT NULL,
  `rev_title` char(254) NOT NULL,
  `rev_body` mediumtext NOT NULL,
  `rev_last_update` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  `rev_create_date` datetime NOT NULL,
  PRIMARY KEY  (`rev_id`),
  KEY `uid` (`uid`),
  KEY `bnum` (`bnum`),
  KEY `repos_id` (`repos_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `insurge_reviews_seq`
--

CREATE TABLE IF NOT EXISTS `insurge_reviews_seq` (
  `sequence` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`sequence`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1295 ;

-- --------------------------------------------------------

--
-- Table structure for table `insurge_tags`
--

CREATE TABLE IF NOT EXISTS `insurge_tags` (
  `tid` int(12) NOT NULL,
  `repos_id` char(24) default NULL,
  `group_id` char(12) default NULL,
  `uid` varchar(12) default NULL,
  `bnum` int(12) NOT NULL,
  `tag` varchar(256) NOT NULL,
  `namespace` varchar(256) NOT NULL,
  `predicate` varchar(256) NOT NULL,
  `value` varchar(256) NOT NULL,
  `tag_date` datetime NOT NULL,
  PRIMARY KEY  (`tid`),
  KEY `repos_id` (`repos_id`),
  KEY `uid` (`uid`),
  KEY `bnum` (`bnum`),
  KEY `tag` (`tag`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `insurge_tags_seq`
--

CREATE TABLE IF NOT EXISTS `insurge_tags_seq` (
  `sequence` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`sequence`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28383 ;

-- --------------------------------------------------------

--
-- Table structure for table `locum_availability`
--

CREATE TABLE IF NOT EXISTS `locum_availability` (
  `bnum` mediumint(8) unsigned NOT NULL,
  `ages` varchar(128) NOT NULL,
  `locations` varchar(128) NOT NULL,
  `available` blob NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`bnum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `locum_bib_items`
--

CREATE TABLE IF NOT EXISTS `locum_bib_items` (
  `bnum` mediumint(13) NOT NULL,
  `author` char(254) collate utf8_unicode_ci default NULL,
  `addl_author` mediumtext collate utf8_unicode_ci,
  `title` varchar(512) collate utf8_unicode_ci NOT NULL,
  `title_medium` char(64) collate utf8_unicode_ci default NULL,
  `edition` char(64) collate utf8_unicode_ci default NULL,
  `series` char(254) collate utf8_unicode_ci default NULL,
  `callnum` char(48) collate utf8_unicode_ci default NULL,
  `pub_info` char(254) collate utf8_unicode_ci default NULL,
  `pub_year` smallint(4) default NULL,
  `stdnum` char(32) collate utf8_unicode_ci default NULL,
  `upc` bigint(12) unsigned zerofill NOT NULL,
  `lccn` char(32) collate utf8_unicode_ci default NULL,
  `descr` mediumtext collate utf8_unicode_ci,
  `notes` mediumtext collate utf8_unicode_ci,
  `subjects` mediumtext collate utf8_unicode_ci,
  `lang` char(12) collate utf8_unicode_ci default NULL,
  `loc_code` char(7) collate utf8_unicode_ci NOT NULL,
  `mat_code` char(7) collate utf8_unicode_ci NOT NULL,
  `cover_img` char(254) collate utf8_unicode_ci default NULL,
  `modified` datetime NOT NULL,
  `bib_created` date NOT NULL,
  `bib_lastupdate` date NOT NULL,
  `bib_prevupdate` date NOT NULL,
  `bib_revs` int(4) NOT NULL,
  `active` enum('0','1') collate utf8_unicode_ci NOT NULL default '1',
  PRIMARY KEY  (`bnum`),
  KEY `modified` (`modified`),
  KEY `mat_code` (`mat_code`),
  KEY `pub_year` (`pub_year`),
  KEY `active` (`active`),
  KEY `bib_lastupdate` (`bib_lastupdate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Item table for Bib records';

-- --------------------------------------------------------

--
-- Table structure for table `locum_bib_items_locations`
--

CREATE TABLE IF NOT EXISTS `locum_bib_items_locations` (
  `id` int(11) NOT NULL auto_increment,
  `bnum` int(13) NOT NULL,
  `locid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `locum_bib_items_subject`
--

CREATE TABLE IF NOT EXISTS `locum_bib_items_subject` (
  `bnum` int(13) NOT NULL,
  `subjects` char(254) NOT NULL,
  KEY `bnum` (`bnum`),
  KEY `subjects` (`subjects`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Table for bibliographic subject headings';

-- --------------------------------------------------------

--
-- Table structure for table `locum_bib_locations`
--

CREATE TABLE IF NOT EXISTS `locum_bib_locations` (
  `id` int(11) NOT NULL auto_increment,
  `location_name` varchar(256) NOT NULL,
  `display_name` varchar(256) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_name` (`location_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `locum_covercache`
--

CREATE TABLE IF NOT EXISTS `locum_covercache` (
  `bnum` int(10) unsigned NOT NULL,
  `cover_stdnum` varchar(16) NOT NULL,
  `updated` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`bnum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `locum_facet_heap`
--

CREATE TABLE IF NOT EXISTS `locum_facet_heap` (
  `bnum` mediumint(13) NOT NULL,
  `series` char(254) default NULL,
  `mat_code` char(7) NOT NULL,
  `loc_code` char(7) NOT NULL,
  `lang` char(12) default NULL,
  `pub_year` smallint(4) NOT NULL default '0',
  `pub_decade` smallint(4) default NULL,
  `bib_lastupdate` date NOT NULL,
  `ages` varchar(128) NOT NULL,
  PRIMARY KEY  (`bnum`),
  KEY `series` USING BTREE (`series`),
  KEY `mat_code` USING BTREE (`mat_code`),
  KEY `loc_code` USING BTREE (`loc_code`),
  KEY `lang` USING BTREE (`lang`),
  KEY `pub_year` USING BTREE (`pub_decade`),
  KEY `bib_lastupdate` USING BTREE (`bib_lastupdate`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `locum_holds_count`
--

CREATE TABLE IF NOT EXISTS `locum_holds_count` (
  `bnum` int(12) NOT NULL,
  `hold_count_week` int(6) NOT NULL default '0',
  `hold_count_month` int(6) NOT NULL default '0',
  `hold_count_year` int(6) NOT NULL default '0',
  `hold_count_total` int(6) NOT NULL default '0',
  PRIMARY KEY  (`bnum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `locum_holds_placed`
--

CREATE TABLE IF NOT EXISTS `locum_holds_placed` (
  `bnum` int(12) NOT NULL,
  `hold_date` date NOT NULL,
  KEY `bnum` (`bnum`,`hold_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `locum_inum_to_bnum`
--

CREATE TABLE IF NOT EXISTS `locum_inum_to_bnum` (
  `inum` int(10) unsigned NOT NULL,
  `bnum` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`inum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `locum_tokens`
--

CREATE TABLE IF NOT EXISTS `locum_tokens` (
  `uid` int(11) NOT NULL,
  `token` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sample_bibs`
--

CREATE TABLE IF NOT EXISTS `sample_bibs` (
  `bnum` mediumint(8) NOT NULL,
  `upc` bigint(12) unsigned zerofill NOT NULL,
  `tracks` text NOT NULL,
  KEY `bnum` (`bnum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sample_tracks`
--

CREATE TABLE IF NOT EXISTS `sample_tracks` (
  `bnum` mediumint(8) NOT NULL,
  `track` mediumint(2) unsigned zerofill NOT NULL,
  `name` varchar(256) NOT NULL,
  KEY `bnum` (`bnum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `syndetics_links`
--

CREATE TABLE IF NOT EXISTS `syndetics_links` (
  `isbn` varchar(14) NOT NULL,
  `links` varchar(256) NOT NULL,
  `updated` date NOT NULL,
  PRIMARY KEY  (`isbn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
