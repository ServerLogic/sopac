#!/usr/bin/php5 -q
<?php
// Init scripts, library locations, and binaries
$locum_lib_dir = '/usr/local/lib/locum';
require_once($locum_lib_dir . '/locum-status.php');
$locum = new locum_status;

$bib = "1239167";
$status = $locum->get_status($bib);
$newstatus['holds'] = $status['holds'];
$newstatus['copies'] = $status['copies'];
$newstatus['order'] = $status['order'];
foreach($status['details'] as $callnum) {
	foreach($callnum as $key => $val) {
		$loc = array_shift(explode(" ",$key));
		$newstatus[$loc]['avail'] += $val['avail'];
		foreach($val['due'] as $due) {
			$newstatus[$loc]['due'][] = $due;
		}
	}
}
print_r($newstatus);
?>
