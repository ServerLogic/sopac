#!/usr/bin/php5 -q
<?php
//ini_set('error_reporting', E_ALL);
ini_set('memory_limit', '400M');
// Init scripts, library locations, and binaries
$locum_lib_dir = '/usr/local/lib/locum';
$mysql_init_script = '/etc/init.d/mysql';
$sphinx_init_script = '/etc/init.d/sphinx';
$sphinx_indexer = '/usr/local/sphinx/bin/indexer';

// Include Locum libraries
require_once($locum_lib_dir . '/locum-server.php');

// Data maintenance
$locum = new locum_server;
echo "starting verify\n";
$locum->verify_bibs();
//$locum->verify_status();
//$locum->verify_syndetics();
echo "verify done\n";
echo "starting new bib scan\n";
$locum->new_bib_scan();
echo "done with new bib scan\n";
echo "starting rebuild of holds cache\n";
$locum->rebuild_holds_cache();
echo "done with all that y'all";

// Restart services, reindex, etc.
//shell_exec($mysql_init_script . ' restart');
//sleep(2);
//shell_exec($sphinx_indexer . '  --all --rotate');
