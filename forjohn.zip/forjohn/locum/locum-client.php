<?php
/**
 * Locum is a software library that abstracts ILS functionality into a
 * catalog discovery layer for use with such things as bolt-on OPACs like
 * SOPAC.
 * @package Locum
 * @author John Blyberg
 */

require_once('locum.php');

/**
 * The Locum Client class represents the "front end" of Locum.  IE, the interactive piece.
 * This is the class you would use to do searches, place holds, get patron info, etc.
 * Ideally, this code should never have to be touched.
 */
class locum_client extends locum {

	/**
	 * Does an index search via Sphinx and returns the results
	 *
	 * @param string $type Search type.  Valid types are: author, title, series, subject, keyword (default)
	 * @param string $term Search term/phrase
	 * @param int $limit Number of results to return
	 * @param int $offset Where to begin result set -- for pagination purposes
	 * @param array $sort_array Numerically keyed array of sort parameters.  Valid options are: newest, oldest
	 * @param array $location_array Numerically keyed array of location params.  NOT IMPLEMENTED YET
	 * @param array $facet_args String-keyed array of facet parameters. See code below for array structure
	 * @return array String-keyed result set
	 */
	public function search($type, $term, $limit, $offset, $sort_opt = NULL, $format_array = array(), $location_array = array(), $facet_args = array(), $override_search_filter = FALSE, $limit_available = FALSE) {
		
		require_once($this->locum_config[sphinx_config][api_path] . '/sphinxapi.php');
		$db =& MDB2::connect($this->dsn);
		
		$term_arr = explode('?', trim(preg_replace('/\//', ' ', $term)));
		$term = trim($term_arr[0]);
		
		if ($term == '*' || $term == '**') { 
			$term = ''; 
		} else {
			$term_prestrip = $term;
			//$term = preg_replace('/[^A-Za-z0-9*\-&()|\!\"\@ ]/iD', '', $term);
			$term = preg_replace('/\*\*/','*', $term);
		}
		$final_result_set[term] = $term;
		$final_result_set[type] = trim($type);

		$cl = new SphinxClient();
		
		$cl->SetServer($this->locum_config[sphinx_config][server_addr], (int) $this->locum_config[sphinx_config][server_port]);

		// As always, defaults to 'keyword'
		$bool = FALSE;
		$cl->SetMatchMode(SPH_MATCH_ALL);
		if($term == "") { $cl->SetMatchMode(SPH_MATCH_ANY); }
		if(preg_match("/ \| /i",$term) || preg_match("/ \-/i",$term) || preg_match("/ \!/i",$term)) { $cl->SetMatchMode(SPH_MATCH_BOOLEAN); $bool = TRUE; }
		if(preg_match("/ OR /i",$term)) { $cl->SetMatchMode(SPH_MATCH_BOOLEAN); $term = preg_replace('/ OR /i',' | ',$term);$bool = TRUE; }
		if(preg_match("/\"/i",$term) || preg_match("/\@/i",$term)) { $cl->SetMatchMode(SPH_MATCH_EXTENDED2); $bool = TRUE; }
		switch ($type) {
			case 'author':
				$cl->SetFieldWeights(array('author' => 50, 'addl_author' => 30));
				$idx = 'bib_items_author';
				break;
			case 'title':
				$cl->SetFieldWeights(array('title' => 50, 'title_medium' => 50, 'series' => 30));
				$idx = 'bib_items_title';
				break;
			case 'series':
				$cl->SetFieldWeights(array('title' => 5, 'series' => 80));
				$idx = 'bib_items_title';
				break;
			case 'subject':
				$idx = 'bib_items_subject';
				break;
			case 'callnum':
				$cl->SetFieldWeights(array('callnum' => 100));
				$idx = 'bib_items_callnum';
				//$cl->SetMatchMode(SPH_MATCH_ANY);
				break;
			case 'tags':
				$cl->SetFieldWeights(array('tag_idx' => 100));
				$idx = 'bib_items_tags';
				$cl->SetMatchMode(SPH_MATCH_PHRASE);
				break;
			case 'reviews':
				$cl->SetFieldWeights(array('review_idx' => 100));
				$idx = 'bib_items_reviews';
				break;
			case 'keyword':
			default:
				$cl->SetFieldWeights(array('title' => 50, 'title_medium' => 50, 'author' => 70, 'addl_author' => 40, 'tag_idx' =>35, 'series' => 25, 'review_idx' => 10, 'notes' => 10, 'subjects' => 5 ));
				$idx = 'bib_items_keyword';
				break;

		}

		// Filter out the records we don't want shown, per locum.ini
		if (!$override_search_filter) {
			if (trim($this->locum_config[location_limits][no_search])) {
				$cfg_filter_arr = parent::csv_parser($this->locum_config[location_limits][no_search]);
				foreach ($cfg_filter_arr as $cfg_filter) {
					$cfg_filter_vals[] = crc32($cfg_filter);
				}
				$cl->SetFilter('loc_code', $cfg_filter_vals, TRUE);
			}
		}

		// Valid sort types are 'newest' and 'oldest'.  Default is relevance.
		switch($sort_opt) {
			case 'newest':
				$cl->SetSortMode(SPH_SORT_EXTENDED, 'pub_year DESC, @relevance DESC');
				break;
			case 'oldest':
				$cl->SetSortMode(SPH_SORT_EXTENDED, 'pub_year ASC, @relevance DESC');
				break;
			case 'catalog_newest':
				$cl->SetSortMode(SPH_SORT_EXTENDED, 'bib_created DESC, @relevance DESC');
				break;
			case 'catalog_oldest':
				$cl->SetSortMode(SPH_SORT_EXTENDED, 'bib_created ASC, @relevance DESC');
				break;
			case 'title':
				$cl->SetSortMode(SPH_SORT_ATTR_ASC, 'title_ord');
				break;
			case 'author':
				$cl->SetSortMode(SPH_SORT_EXTENDED, 'author_null ASC, author_ord ASC');
				break;
			case 'top_rated':
				$cl->SetSortMode(SPH_SORT_ATTR_DESC, 'rating_idx');
				break;
			case 'popular_week':
				$cl->SetSortMode(SPH_SORT_ATTR_DESC, 'hold_count_week');
				break;
			case 'popular_month':
				$cl->SetSortMode(SPH_SORT_ATTR_DESC, 'hold_count_month');
				break;
			case 'popular_year':
				$cl->SetSortMode(SPH_SORT_ATTR_DESC, 'hold_count_year');
				break;
			case 'popular_total':
				$cl->SetSortMode(SPH_SORT_ATTR_DESC, 'hold_count_total');
				break;
			case 'atoz':
				$cl->SetSortMode(SPH_SORT_ATTR_ASC, 'title_ord');
				break;
			case 'ztoa':
				$cl->SetSortMode(SPH_SORT_ATTR_DESC, 'title_ord');
				break;
			default:
				$cl->SetSortMode(SPH_SORT_RELEVANCE);
				break;
		}

		// Filter by material types
		if (is_array($format_array)) {
			foreach ($format_array as $format) {
				if (strtolower($format) != 'all') {
					$filter_arr_mat[] = crc32(trim($format));
				}
			}
			if (count($filter_arr_mat)) { $cl->SetFilter('mat_code', $filter_arr_mat); }
		}
		
		// Filter by location
		if (count($location_array)) {
			foreach ($location_array as $location) {
				if (strtolower($location) != 'all') {
					$filter_arr_loc[] = crc32(trim($location));
				}
			}
			if (count($filter_arr_loc)) { $cl->SetFilter('loc_code', $filter_arr_loc); }
		}
		$cl->SetRankingMode(SPH_RANK_WORDCOUNT);
		$cl->SetLimits(0, 5000, 5000);
	//	$cl->SetMatchMode($match_type);
		$sph_res_all = $cl->Query($term, $idx); // Grab all the data for the facetizer

		if(empty($sph_res_all[matches]) && $bool == FALSE && $term != "*" && $type != "tags") {
			$term = '"'.$term.'"/1';
			$cl->SetMatchMode(SPH_MATCH_EXTENDED2);
			$sph_res_all = $cl->Query($term, $idx);
			$forcedchange = 'yes';
		}
		$cl->SetLimits((int) $offset, (int) $limit);

		// And finally.... we search.
		$sph_res = $cl->Query($term, $idx);
		
		// Include descriptors
		$final_result_set[num_hits] = $sph_res[total];
		if ($sph_res[total] <= $this->locum_config[api_config][suggestion_threshold]) {
			if ($this->locum_config[api_config][use_google_suggest] == TRUE) {
				$final_result_set[suggestion] = self::google_suggest($term_prestrip);
			}
		}
		
		if (is_array($sph_res[matches])) {
			foreach ($sph_res[matches] as $bnum => $attr) {
				$bib_hits[] = $bnum;
			}
		}
		if (is_array($sph_res_all[matches])) {
			foreach ($sph_res_all[matches] as $bnum => $attr) {
				$bib_hits_all[] = $bnum;
			}
		}
		
		// Limit list to available
		if ($limit_available && $final_result_set[num_hits]) {
			$limit_available = strval($limit_available);
			// remove bibs from full list that we *know* are unavailable
			$cache_cutoff = date("Y-m-d H:i:00", time() - 3600); // 1 hour
			if (array_key_exists($limit_available, $this->locum_config['locations'])) {
				$location_sql = "NOT LIKE '%$limit_available%'"; // if location passed in, filter out by that location, otherwise just the ones that are empty
			} else {
				$location_sql = "= ''";
			}
			$utf = "SET NAMES 'utf8' COLLATE 'utf8_unicode_ci'";
			$utfprep = $db->query($utf);
			$sql = "SELECT bnum FROM locum_availability WHERE bnum IN (" . implode(", ", $bib_hits_all) . ") AND locations $location_sql AND timestamp > '$cache_cutoff'";
			$init_result =& $db->query($sql);
			$unavail_bibs = $init_result->fetchCol();
			$bib_hits_all = array_values(array_diff($bib_hits_all,$unavail_bibs));

			unset($bib_hits); // rebuild from the full list
			$available_count = 0;
			foreach ($bib_hits_all as $key => $bib_hit) {
				$bib_avail = self::get_availability($bib_hit);
				$available = (array_key_exists($limit_available, $this->locum_config['locations']) ? is_array($bib_avail['locations'][$limit_available]) : ($bib_avail['total'] > 0));
				if ($available) {
					$available_count++;
					if ($available_count > $offset) {
						$bib_hits[] = $bib_hit;
						if (count($bib_hits) == $limit) {
							//found as many as we need for this page
							break;
						}
					}
				} else {
					// remove the bib from the bib_hits_all array
					unset($bib_hits_all[$key]);
				}
			}
			// trim out the rest of the array based on *any* cache value
			if(!empty($bib_hits_all)) {
				$sql = "SELECT bnum FROM locum_availability WHERE bnum IN (" . implode(", ", $bib_hits_all) . ") AND locations $location_sql";
				$init_result =& $db->query($sql);
				if($init_result){	
					$unavail_bibs =& $init_result->fetchCol();
					$bib_hits_all = array_values(array_diff($bib_hits_all,$unavail_bibs));
				}
			}
			$final_result_set[num_hits] = count($bib_hits_all);
		}
		
		// Refine by facets
		if (count($facet_args)) {
			$where = '';

			// Series
			if ($facet_args[facet_series]) {
				$where .= ' AND (';
				$or = '';
				foreach ($facet_args[facet_series] as $series) {
					$where .= $or . ' series LIKE \'' . $db->escape($series, 'text') . '%\'';
					$or = ' OR';
				}
				$where .= ')';
			}

			// Language
			if ($facet_args[facet_lang]) {
				foreach ($facet_args[facet_lang] as $lang) {
					$lang_arr[] = $db->quote($lang, 'text');
				}
				$where .= ' AND lang IN (' . implode(', ', $lang_arr) . ')';
			}
			// Pub. Year
			if ($facet_args[facet_year]) {
				$where .= ' AND pub_decade IN (' . implode(', ', $facet_args[facet_year]) . ')';
			}
			// Ages
			if ($facet_args['age']) {
				$where .= " AND ages LIKE '%" . $facet_args['age'] . "%'";
			}
			if(!empty($bib_hits_all)) {
			$sql1 = 'SELECT bnum FROM locum_facet_heap WHERE bnum IN (' . implode(', ', $bib_hits_all) . ')' . $where;
			$sql2 = 'SELECT bnum FROM locum_facet_heap WHERE bnum IN (' . implode(', ', $bib_hits_all) . ')' . $where . " LIMIT $offset, $limit";
			$utf = "SET NAMES 'utf8' COLLATE 'utf8_unicode_ci'";
			$utfprep = $db->query($utf);
			$init_result =& $db->query($sql1);
			$bib_hits_all = $init_result->fetchCol();
			$init_result =& $db->query($sql2);
			$bib_hits = $init_result->fetchCol();
			}
			$facet_total = count($bib_hits_all);
			$final_result_set[num_hits] = $facet_total;
		}

		// First, we have to get the values back, unsorted against the Sphinx-sorted array
		if (count($bib_hits)) {
			$sql = 'SELECT * FROM locum_bib_items WHERE bnum IN (' . implode(', ', $bib_hits) . ')';
			$utf = "SET NAMES 'utf8' COLLATE 'utf8_unicode_ci'";
			$utfprep = $db->query($utf);
			$init_result =& $db->query($sql);
			$init_bib_arr = $init_result->fetchAll(MDB2_FETCHMODE_ASSOC);
			foreach ($init_bib_arr as $init_bib) {
				// Get availability
				$init_bib['availability'] = self::get_availability($init_bib['bnum']);
				$bib_reference_arr[(string) $init_bib[bnum]] = $init_bib;
			}

			// Now we reconcile against the sphinx result
			foreach ($sph_res_all[matches] as $sph_bnum => $sph_binfo) {
				if (in_array($sph_bnum, $bib_hits)) {
					$final_result_set[results][] = $bib_reference_arr[$sph_bnum];
				}
			}

		}
		$db->disconnect();
		$final_result_set[facets] = self::facetizer($bib_hits_all);
		if($forcedchange == 'yes') { $final_result_set['changed'] = 'yes'; }
		return $final_result_set;
	}

	/**
	 * Formulates the array used to put together the faceted search panel.
	 * This function is called from the search function.
	 *
	 * @param array $bib_hits_all Standard array of bib numbers
	 * @return array Faceted array of information for bib numbers passed.  Keyed by: mat, series, loc, lang, pub_year
	 */
	public function facetizer($bib_hits_all) {
		$db = MDB2::connect($this->dsn);
		if (count($bib_hits_all)) {
			$where_str = 'WHERE bnum in (' . implode(",", $bib_hits_all) . ')';

			$sql[mat] = 'SELECT DISTINCT mat_code, COUNT(mat_code) AS mat_code_sum FROM locum_facet_heap ' . $where_str . ' GROUP BY mat_code ORDER BY mat_code_sum DESC';
			$sql[series] = 'SELECT DISTINCT series, COUNT(series) AS series_sum FROM locum_facet_heap ' . $where_str . ' GROUP BY series ORDER BY series ASC';
			$sql[loc] = 'SELECT DISTINCT loc_code, COUNT(loc_code) AS loc_code_sum FROM locum_facet_heap ' . $where_str . ' GROUP BY loc_code ORDER BY loc_code_sum DESC';
			$sql[lang] = 'SELECT DISTINCT lang, COUNT(lang) AS lang_sum FROM locum_facet_heap ' . $where_str . ' GROUP BY lang ORDER BY lang_sum DESC';
			$sql[pub_year] = 'SELECT DISTINCT pub_decade, COUNT(pub_decade) AS pub_year_sum FROM locum_facet_heap ' . $where_str . ' GROUP BY pub_decade ORDER BY pub_decade DESC';

			foreach ($sql AS $fkey => $fquery) {
				$tmp_res =& $db->query($fquery);
				$tmp_res_arr = $tmp_res->fetchAll();
				foreach ($tmp_res_arr as $values) {
					if ($values[0] && $values[1]) { $result[$fkey][$values[0]] = $values[1]; }
				}
			}
			
			// Create non-distinct facets for age
			foreach ($this->locum_config['ages'] as $age_code => $age_name) {
				$sql = "SELECT COUNT(bnum) as age_sum FROM locum_facet_heap $where_str AND ages LIKE '%$age_code%'";
				$res =& $db->query($sql);
				$result['ages'][$age_code] = $res->fetchOne();
			}
			
			// Create facets from availability cache
			$sql = "SELECT COUNT(bnum) as avail_sum FROM locum_availability $where_str AND locations != ''";
			$res =& $db->query($sql);
			$result['avail']['any'] = $res->fetchOne();
			foreach ($this->locum_config['locations'] as $loc_code => $loc_name) {
				$sql = "SELECT COUNT(bnum) as avail_sum FROM locum_availability $where_str AND locations LIKE '%$loc_code%'";
				$res =& $db->query($sql);
				$result['avail'][$loc_code] = $res->fetchOne();
			}
			
			$db->disconnect();
			return $result;
		}
	}

	/**
	 * Returns an array of item status info (availability, location, status, etc).
	 *
	 * @param string $bnum Bib number
	 * @return array Detailed item availability 
	 */
	public function get_item_status($bnum) {
		$result = $this->locum_cntl->item_status($bnum);
		return $result;
	}
	
	/**
	 * Returns information about a bib title.
	 *
	 * @param string $bnum Bib number
	 * @return array Bib item information
	 */
	public function get_bib_item($bnum) {
		$db = MDB2::connect($this->dsn);
		$utf = "SET NAMES 'utf8' COLLATE 'utf8_unicode_ci'";
		$utfprep = $db->query($utf);
		$res = $db->query("SELECT * FROM locum_bib_items WHERE bnum = '$bnum' AND active = '1' LIMIT 1");
		$item_arr = $res->fetchAll(MDB2_FETCHMODE_ASSOC);
		$db->disconnect();
		return $item_arr[0];
	}
	
	public function get_cd_tracks($bnum) {
		$db =& MDB2::connect($this->dsn);
		$res =& $db->query("SELECT * FROM sample_tracks WHERE bnum = '$bnum' ORDER BY track");
		$item_arr = $res->fetchAll(MDB2_FETCHMODE_ASSOC);
		$db->disconnect();
		return $item_arr;
	}
	
	public function get_upc($bnum) {
		$db =& MDB2::connect($this->dsn);
		$res =& $db->query("SELECT upc FROM sample_bibs WHERE bnum = '$bnum'");
		$item_arr = $res->fetchAll(MDB2_FETCHMODE_ASSOC);
		$db->disconnect();
		return $item_arr[0];
	}
	
	public function get_syndetics($isbn = NULL) {
		if($isbn == NULL) {
			return FALSE;
		}
		$valid_hits = array(
			'TOC' => 'Table of Contents',
			'BNATOC' => 'Table of Contents',
			'FICTION' => 'Fiction Profile',
			'SUMMARY' => 'Summary / Annotation',
			'DBCHAPTER' => 'Excerpt',
			'LJREVIEW' => 'Library Journal Review',
			'PWREVIEW' => 'Publishers Weekly Review',
			'SLJREVIEW' => 'School Library Journal Review',
			'CHREVIEW' => 'CHOICE Review',
			'BLREVIEW' => 'Booklist Review',
			'HORNBOOK' => 'Horn Book Review',
			'KIRKREVIEW' => 'Kirkus Book Review',
			'ANOTES' => 'Author Notes'
		);
		$db =& MDB2::connect($this->dsn);
		$cutoffdate = date('Y-m-d', strtotime('- 2 months'));
		$res = $db->query("SELECT links FROM syndetics_links WHERE isbn = '$isbn' LIMIT 1");
		$dbres = $res->fetchAll(MDB2_FETCHMODE_ASSOC);
		if ($dbres[0][links]) {
			$links = explode('|', $dbres[0][links]);
		} else {
			/*
$xmlurl = "http://www.syndetics.com/index.aspx?isbn=$isbn/index.xml&client=anarp&type=xw10";
			$xmlraw = file_get_contents($xmlurl);
			if (!preg_match('/error/', $xmlraw)) {
				// record found
				$xmlobj = (array) simplexml_load_string($xmlraw);
				$delimit = '';
				foreach ($xmlobj as $xkey => $xval) {
					if (array_key_exists($xkey, $valid_hits)) {
						$sqlfield .= $delimit . $xkey;
						$delimit = '|';
						$links[] = $xkey;
					}
				}
				if ($sqlfield) {
					$res = $db->query("INSERT INTO syndetics_links VALUES ('$isbn', '$sqlfield', NOW())");
				}
			}
*/
		}
		if ($links) {
			foreach ($links as $link) {
				$retstr .= '<li><a href="http://www.syndetics.com/index.aspx?isbn=' . $isbn . '/' . $link . '.html&client=anarp" target="_new">' . $valid_hits[$link] . '</a></li>';
			}
		}
	$db->disconnect();
	return $retstr;

	}
	
	/**
	 * Returns information about an array of bib titles.
	 *
	 * @param array $bnum_arr Bib number array
	 * @return array Bib item information for $bnum_arr
	 */
	public function get_bib_items_arr($bnum_arr) {
		if (count($bnum_arr)) {
			$db =& MDB2::connect($this->dsn);
			$sql = 'SELECT * FROM locum_bib_items WHERE bnum IN (' . implode(', ', $bnum_arr) . ')';
			$res =& $db->query($sql);
			$item_arr = $res->fetchAll(MDB2_FETCHMODE_ASSOC);
			$db->disconnect();
			foreach ($item_arr as $item) {
				$bib[(string) $item[bnum]] = $item;
			}
		}
		return $bib;
	}

	/**
	 * Returns an array of patron information
	 *
	 * @param string $pid Patron barcode number or record number
	 * @return boolean|array Array of patron information or FALSE if login fails
	 */
	public function get_patron_info($pid) {
		$patron_info = $this->locum_cntl->patron_info($pid);
		return $patron_info;
	}

	/**
	 * Returns an array of patron checkouts
	 *
	 * @param string $cardnum Patron barcode/card number
	 * @param string $pin Patron pin/password
	 * @return boolean|array Array of patron checkouts or FALSE if $barcode doesn't exist
	 */
	public function get_patron_checkouts($cardnum, $pin = NULL) {
		$patron_checkouts = $this->locum_cntl->patron_checkouts($cardnum, $pin);
		foreach($patron_checkouts as &$patron_checkout) {
			// lookup bnum from inum
			if (!$patron_checkout['bnum']) {
				$patron_checkout['bnum'] = self::inum_to_bnum($patron_checkout['inum']);
			}
			if($patron_checkout['ill'] == 0) {
				$bib = self::get_bib_item($patron_checkout['bnum']);
				$patron_checkout['bib'][] = $bib;
				$patron_checkout['avail'] = self::get_availability($patron_checkout['bnum']);
				//$patron_checkout['title'] = $bib['title'];
				if($bib['author'] != '') {
					$patron_checkout['author'] = $bib['author'];
				}
				$patron_checkout['addl_author'] = $bib['addl_author'];
				//if($bib['author']) {$patron_checkout['author'] = $bib['author']};
			}
		}
		return $patron_checkouts;
	}
	
	/**
	 * Returns an array of patron holds
	 *
	 * @param string $cardnum Patron barcode/card number
	 * @param string $pin Patron pin/password
	 * @return boolean|array Array of patron holds or FALSE if login fails
	 */
	public function get_patron_holds($cardnum, $pin = NULL) {
		$patron_holds = $this->locum_cntl->patron_holds($cardnum, $pin);
		foreach($patron_holds as &$patron_hold) {
			if($patron_hold['ill'] == 0) {
				$bib = $this->get_bib_item($patron_hold['bnum']);
				$patron_hold['bib'][] = $bib;
				$patron_hold['title'] = $bib['title'];
				if($bib['author'] != '') {
					$patron_hold['author'] = $bib['author'];
				}
				$patron_hold['addl_author'] = $bib['addl_author'];
				//if($bib['author']) {$patron_checkout['author'] = $bib['author']};
			}
		}
		return $patron_holds;
	}
	
	/**
	 * Renews items and returns the renewal result
	 *
	 * @param string $cardnum Patron barcode/card number
	 * @param string $pin Patron pin/password
	 * @param array Array of varname => item numbers to be renewed, or NULL for everything.
	 * @return boolean|array Array of item renewal statuses or FALSE if it cannot renew for some reason
	 */
	public function renew_items($cardnum, $pin = NULL, $items = NULL) {
		$renew_status = $this->locum_cntl->renew_items($cardnum, $pin, $items);
		return $renew_status;
	}

	/**
	 * Cancels holds
	 *
	 * @param string $cardnum Patron barcode/card number
	 * @param string $pin Patron pin/password
	 * @param array Array of varname => item numbers to be renewed, or NULL for everything.
	 * @return boolean TRUE or FALSE if it cannot cancel for some reason
	 */
	public function cancel_holds($cardnum, $pin = NULL, $items = NULL) {
		$cancel_status = $this->locum_cntl->cancel_holds($cardnum, $pin, $items);
		return $cancel_status;
	}
	
	/**
	 * Places holds
	 *
	 * @param string $cardnum Patron barcode/card number
	 * @param string $bnum Bib item record number to place a hold on
	 * @param string $varname additional variable name (such as an item number for item-level holds) to place a hold on
	 * @param string $pin Patron pin/password
	 * @param string $pickup_loc Pickup location value
	 * @return boolean TRUE or FALSE if it cannot place the hold for some reason
	 */
	public function place_hold($cardnum, $bnum, $varname = NULL, $pin = NULL, $pickup_loc = NULL) {
		$request_status = $this->locum_cntl->place_hold($cardnum, $bnum, $varname, $pin, $pickup_loc);
		if ($request_status[success]) {
			$db =& MDB2::connect($this->dsn);
			$db->query("INSERT INTO locum_holds_placed VALUES ('$bnum', NOW())");
		}
		return $request_status;
	}
	
	/**
	 * Returns an array of patron fines
	 *
	 * @param string $cardnum Patron barcode/card number
	 * @param string $pin Patron pin/password
	 * @return boolean|array Array of patron holds or FALSE if login fails
	 */
	public function get_patron_fines($cardnum, $pin = NULL) {
		$patron_fines = $this->locum_cntl->patron_fines($cardnum, $pin);
		return $patron_fines;
	}
	
	/**
	 * Pays patron fines.
	 * $payment_details structure:
	 * [varnames] 		= An array of varnames to id which fines to pay.
	 * [total]			= payment total.
	 * [name]			= Name on the credit card.
	 * [address1]		= Billing address.
	 * [address2]		= Billing address.  (opt)
	 * [city]			= Billing address city.
	 * [state]			= Billing address state.
	 * [zip]			= Billing address zip.
	 * [email]			= Cardholder email address.
	 * [ccnum]			= Credit card number.
	 * [ccexpmonth]		= Credit card expiration date.
	 * [ccexpyear]		= Credit card expiration year.
	 * [ccseccode]		= Credit card security code.
	 *
	 * @param string $cardnum Patron barcode/card number
	 * @param string $pin Patron pin/password
	 * @param array payment_details
	 * @return array Payment result
	 */
	public function pay_patron_fines($cardnum, $pin = NULL, $payment_details) {
		$payment_result = $this->locum_cntl->pay_patron_fines($cardnum, $pin, $payment_details);
		return $payment_result;
	}
	
	public function get_uid_from_token($token) {
		$db = MDB2::connect($this->dsn);
		$sql = "SELECT * FROM locum_tokens WHERE token = '$token' LIMIT 1";
		$res = $db->query($sql);
		$patron_arr = $res->fetchAll(MDB2_FETCHMODE_ASSOC);
		return $patron_arr[0]['uid'];
	}
	
	public function get_token($uid) {
		$db = MDB2::connect($this->dsn);
		$sql = "SELECT * FROM locum_tokens WHERE uid = '$uid' LIMIT 1";
		$res = $db->query($sql);
		$patron_arr = $res->fetchAll(MDB2_FETCHMODE_ASSOC);
		return $patron_arr[0]['token'];
	}
	/**
	 * Formulates "Did you mean?" I may move to the Yahoo API for this..
	 * 
	 * @param string $str String to check
	 * @return string|boolean Either returns a string suggestion or FALSE
	 */
	public function google_suggest($str) {
		$str_array = explode( ' ', $str );
		$words = implode( '+', $str_array );
		$ch = curl_init();
		$url = "http://www.google.com/search?q=" . $words;
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		$html = curl_exec($ch);
		curl_close($ch);
		preg_match_all('/Did you mean: <\/font><a href=(.*?)class=p>(.*?)<\/a>/i', $html, $spelling1);
		preg_match_all('/See results for:(.*?)>(.*?)<\/a>/i', $html, $spelling2);

		if (isset($spelling1[2][0])) {
			return strip_tags($spelling1[2][0]);
		} else if (isset($spelling2[2][0])) {
			return strip_tags($spelling2[2][0]);
		} else {
			return FALSE;
		}
	}

	/**
	 * grab availability information by branch and age group
	 *
	 */
  public function get_availability($bnum = 0, $force_refresh = FALSE) {
  	if($bnum == 0) { return FALSE; }
    $db = MDB2::connect($this->dsn);
    $cache_cutoff = date("Y-m-d H:i:s", time() - 3600); // 1 hour
		$items = array();
		$cached = FALSE;

    if (!$force_refresh) {
			// check the cache table
			$sql = "SELECT * FROM locum_availability WHERE bnum = :bnum AND timestamp > '$cache_cutoff'";
			$statement = $db->prepare($sql, array('integer'));
			$result = $statement->execute(array('bnum' => $bnum));
			if (PEAR::isError($result) && $this->cli) {
				echo "DB connection failed... " . $results->getMessage() . "\n";
			}
			$statement->Free();
			$cached = $result->NumRows();
		}
    if ($cached) {
			$row = $result->fetchRow(MDB2_FETCHMODE_ASSOC);
			$avail_array = unserialize($row['available']);
    } else {
      // get fresh info from the catalog
      $iii_webcat = $this->locum_config[ils_config][ils_server];
      $avail_token = locum::csv_parser($this->locum_config[ils_custom_config][iii_available_token]);
			$bnum = trim($bnum);
      $ages = array();
      $avail_array = array();
			$call_nums = array();
			$locations = array();

			// Grab Hold Numbers
			$url = 'http://' . $iii_webcat . '/search~24/.b' . $bnum . '/.b' . $bnum . '/1,1,1,B/marc~' . $bnum . '&FF=&1,0,';
			$hold_page_raw = utf8_encode(file_get_contents($url));
			// Reserves Regex
			$regex_r = '/(?<hold_num>\d+) hold/';
			preg_match($regex_r, $hold_page_raw, $match_r);
			$avail_array['holds'] = $match_r['hold_num'] ? $match_r['hold_num'] : 0;
	
			// Order Entry Regex
			$regex_o = '%bibOrderEntry(.*?)td(.*?)>(.*?)<%s';
			preg_match_all($regex_o, $hold_page_raw, $match_o);
			foreach($match_o[3] as $order) {
				$avail_array['orders'][] = trim($order);
			}
			
			// Grab Availability
      $url = 'http://' . $iii_webcat . '/search~24/.b' . $bnum . '/.b' . $bnum . '/1,1,1,B/holdings~' . $bnum . '&FF=&1,0,';
      $avail_page_raw = utf8_encode(file_get_contents($url));
  
      // Holdings Regex
      $regex_h = '%field 1 -->&nbsp;(.*?)</td>(.*?)browse">(.*?)</a>(.*?)field \% -->&nbsp;(.*?)</td>%s';
      preg_match_all($regex_h, $avail_page_raw, $matches);
      // $matches[1] = location, $matches[3] = Call #, $matches[5] = Status
			
      foreach ($matches[1] as $i => $location) {
				// put the item details in the array
				$location = trim($location);
				$call = str_replace("'", "&apos;", trim($matches[3][$i]));
				$status = trim($matches[5][$i]);
				$avail_array['items'][] = array('location' => $location, 'call' => $call, 'status' => $status);
				
        $location = explode(" ", $location);
				$branch = $location[0];
				if ($loc_code = array_search($branch, $this->locum_config['locations'])) {
					if (!$age = array_search($location[1], $this->locum_config['ages'])) {
						$age = array_shift(array_keys($this->locum_config['ages'])); // default to first age key in config
					}
					if (!in_array($age, $ages)) {
						$ages[] = $age;
					}				
					if (in_array($status, $avail_token)) {
						if (!in_array($loc_code, $locations)) {
							$locations[] = $loc_code;
						}
						$avail_array['total']++;
						$avail_array['locations'][$loc_code][$age]++;
					}
				}
				// Grab ALL Call Numbers, not just available items
				if (!in_array($call, $call_nums)) {
					$call_nums[] = $call;
				}
      }
			$ages = implode(",", $ages);
			$locations = implode(",", $locations);
			$avail_array['call_nums'] = $call_nums;
			
			// update cache
			$avail_blob = serialize($avail_array);
			$sql = "REPLACE INTO locum_availability (bnum, ages, locations, available) VALUES (:bnum, '$ages', '$locations', '$avail_blob')";
			$statement = $db->prepare($sql, array('integer'));
			$result = $statement->execute(array('bnum' => $bnum));
			if (PEAR::isError($result) && $this->cli) {
				echo "DB connection failed... " . $results->getMessage() . "\n";
			}
			$statement->Free();
    }
		return $avail_array;
  }
	
	public function inum_to_bnum($inum, $force_refresh = FALSE) {
		$inum = intval($inum);
		$db = MDB2::connect($this->dsn);
    $cache_cutoff = date("Y-m-d H:i:s", time() - 60 * 60 * 24 * 7); // 1 week
		$cached = FALSE;

    if (!$force_refresh) {
			// check the cache table
			$sql = "SELECT * FROM locum_inum_to_bnum WHERE inum = :inum AND timestamp > '$cache_cutoff'";
			$statement = $db->prepare($sql, array('integer'));
			$result = $statement->execute(array('inum' => $inum));
			if (PEAR::isError($result) && $this->cli) {
				echo "DB connection failed... " . $results->getMessage() . "\n";
			}
			$statement->Free();
			$cached = $result->NumRows();
		}
    if ($cached) {
			$row = $result->fetchRow(MDB2_FETCHMODE_ASSOC);
			$bnum = $row['bnum'];
    } else {
			// get fresh info from the catalog
      $iii_webcat = $this->locum_config[ils_config][ils_server];
			$url = 'http://' . $iii_webcat . '/record=i' . $inum;
			$bib_page_raw = utf8_encode(file_get_contents($url));
			preg_match('/marc~b([0-9]*)/', $bib_page_raw, $bnum_raw_match);
			$bnum = $bnum_raw_match[1];
			
			if ($bnum) {
				$sql = "REPLACE INTO locum_inum_to_bnum (inum, bnum) VALUES (:inum, :bnum)";
				$statement = $db->prepare($sql, array('integer', 'integer'));
				$result = $statement->execute(array('inum' => $inum, 'bnum' => $bnum));
				if (PEAR::isError($result) && $this->cli) {
					echo "DB connection failed... " . $results->getMessage() . "\n";
				}
				$statement->Free();
			}
		}
		return $bnum;
	}
}
