<?php
/**
 * Locum is a software library that abstracts ILS functionality into a
 * catalog discovery layer for use with such things as bolt-on OPACs like
 * SOPAC.
 * @package Locum
 * @author Eric J. Klooster
 */

require_once('locum-client.php');

/**
 * This class is the covers component of Locum.
 */

class locum_status extends locum {
	private $cli;
	private $sources_count;
	private $start_time;
	
	public function __construct() {
		$this->start_time = time();
		parent::__construct();
		$this->cli = (php_sapi_name() == "cli");
	}
	
	public function get_batch($break_num, $limit = 100, $type = 'NEW') {
		$limit = intval($limit);
		$db = MDB2::connect($this->dsn);
		if ($type == 'NEW') {
			// Grab the bnums with no corresponding cache table rows
      $sql = "SELECT MIN(bnum) AS start, MAX(bnum) AS end FROM ( " .
             "SELECT locum_bib_items.bnum FROM locum_bib_items " .
             "LEFT JOIN locum_bib_locations ON locum_bib_items.bnum = locum_bib_locations.bnum " .
             "WHERE locum_bib_locations.bnum IS NULL " .
             "AND locum_bib_items.bnum < :break " .
             "ORDER BY locum_bib_items.bnum DESC " .
             "LIMIT $limit " .
             ") AS t1";
    } else {
      // Grab the oldest processed records that don't have a cached image
      $sql = "SELECT MIN(bnum) AS start, MAX(bnum) AS end FROM ( " .
             "SELECT bnum FROM locum_bib_locations " .
             "WHERE cover_stdnum = '' ORDER BY updated ASC " .
             "LIMIT $limit " .
             ") AS t1";
		}
		$statement = $db->prepare($sql, array('integer'));
		$result = $statement->execute(array('break' => $break_num));
		if (PEAR::isError($result) && $this->cli) {
			echo "DB connection failed... " . $results->getMessage() . "\n";
		}
		$statement->Free();
		return $result->fetchRow(MDB2_FETCHMODE_ASSOC);
	}
	
	public function process_covers($start, $end, $type = 'NEW') {
		$num_found = 0;
		$not_found = array();
		$total = 0;
		$db = MDB2::connect($this->dsn);
		
    if ($type == 'NEW') {
			$sql = "SELECT locum_bib_items.* FROM locum_bib_items " .
             "LEFT JOIN locum_covercache ON locum_bib_items.bnum = locum_covercache.bnum " .
             "WHERE locum_covercache.bnum IS NULL " .
             "AND locum_bib_items.bnum >= :start " .
             "AND locum_bib_items.bnum <= :end";
		} else {
			$sql = "";
		}

		$statement = $db->prepare($sql, array('integer', 'integer'));
		$result = $statement->execute(array('start' => $start, 'end' => $end));		
		if (PEAR::isError($result) && $this->cli) {
			echo "DB connection failed... " . $results->getMessage() . "\n";
		}
		$statement->Free();
		
		while($bib_rec = $result->fetchRow(MDB2_FETCHMODE_ASSOC)) {
			$total++;
			if ($bib_rec['stdnum']) {
				// clean the stdnum field to just the number
				ereg("^[0-9a-zA-Z]+", $bib_rec['stdnum'], $regs);
				$bib_rec['stdnum'] = $regs[0];
			}
			if ($this->cli) echo $bib_rec['bnum'] . ": ";
			if ($cover = self::get_coverimage($bib_rec)) {
				if ($this->cli) echo $cover['stdnum'] . "::" . $cover['image_url'] . "\n";
				$num_found++;
				if (self::create_covercache($bib_rec['bnum'], $cover['image_url'])) {
					// Update DB tables with bnum and $cover['stdnum']
					$db->query("UPDATE locum_bib_items SET cover_img = 'CACHE' WHERE bnum = " . $bib_rec['bnum']);
					$sql = "REPLACE INTO locum_covercache SET bnum = :bnum, cover_stdnum = :stdnum";
					$statement = $db->prepare($sql, array('integer', 'text'));
					$statement->execute(array('bnum' => $bib_rec['bnum'], 'stdnum' => $cover['stdnum']));
				} else {
					echo "ERROR CREATING CACHE\n";
				}
			} else {
				// Update covercache table to record timestamp of failure
				$db->query("REPLACE INTO locum_covercache SET bnum = " . $bib_rec['bnum'] . ", cover_stdnum = ''");
				if ($this->cli) echo "IMAGE NOT FOUND Material: " . $this->locum_config['formats'][$bib_rec['mat_code']] . "\n";
				$not_found[$bib_rec['mat_code']]++;
			}
		}
		
		if ($this->cli) {
			$end_time = time();
			$percentage = number_format(($num_found / $total) * 100, 2);
			$average = number_format(($end_time - $this->start_time) / $total, 2);
			echo "\nPROCESSING COMPLETE: $num_found / $total ($percentage%)\n";
			echo "TIME: " . date("m/d/Y H:i:s", $this->start_time) . "-" . date("m/d/Y H:i:s", $end_time);
			echo " ($average sec. avg.)\n";
			echo "Not Found by Material: ";
			foreach ($not_found as $mat_code => $number) {
				echo $this->locum_config['formats'][$mat_code] . ": " . $number . " ";
			}
			echo "\nLOOKUP COUNT: " . $this->lookup_count . " XISBN COUNT: " . $this->xisbn_count . "\n";
			foreach ($this->sources_count as $id => $count) {
				echo $id . " COUNT: " . $count . " ";
			}
			echo "\n";
		}
	}
	
	/**
	 * return an array of related isbns
	 * utilizes worldcat xisbn service
	 */
	public function get_xisbn($isbn) {
		if ($this->xisbn_count < $this->locum_config['xisbn_config']['limit']) {
			if ($this->cli) echo "XISBN ";
			$requestURL = "http://xisbn.worldcat.org/webservices/xid/isbn/$isbn";
			$requestIP = $this->locum_config['xisbn_config']['requestIP'];
			$secret = $this->locum_config['xisbn_config']['secret'];  
			$hash = md5("$requestURL|$requestIP|$secret");
			$token = $this->locum_config['xisbn_config']['token'];
			
			$xml = simplexml_load_file($requestURL . "?method=getEditions&format=xml&token=$token&hash=$hash");
		
			$isbns = array();
			if ($xml->isbn) {
				foreach($xml->isbn as $xisbn) {
					$isbns[] = (string)$xisbn;
				}
			}
			$this->xisbn_count++;
			
			return $isbns;
		}
		else {
			return FALSE; // over the limit for lookups
		}
	}
	
  /**
   * Display a block of covercache statistics.
   */
  public function get_stats() {
    $db = MDB2::connect($this->dsn);
    $total = array_shift($db->queryRow("SELECT COUNT(bnum) FROM locum_bib_items"));
    $processed = array_shift($db->queryRow("SELECT COUNT(locum_bib_items.bnum) FROM locum_bib_items, locum_covercache WHERE locum_bib_items.bnum = locum_covercache.bnum"));
    $cached = array_shift($db->queryRow("SELECT COUNT(locum_bib_items.bnum) FROM locum_bib_items, locum_covercache WHERE locum_bib_items.bnum = locum_covercache.bnum AND locum_covercache.cover_stdnum <> ''"));

    $stats .= "Total Bib Records   : $total\n";
    $stats .= "Records Processed   : $processed (" . number_format(($processed / $total) * 100, 2) . "%)\n";
    $stats .= "Unprocessed Records : " . ($total - $processed) . "\n";
    $stats .= "Covers Cached       : $cached (" . number_format(($cached / $total) * 100, 2) . "%)\n";
    
    return $stats;
  }
  
	/**
	 * retrieve the widest cover image from a given isbn
	 */
	private function isbn_coverimage_url($isbn) {
		if ($this->cli) echo "trying $isbn ";
		$this->lookup_count++;
		$isbn = trim($isbn);
		$images = array();
		$lt_key = "6e6aec9cdd7691dfbf7cafbed38e5ec8";
		
		$sources = $this->locum_config['coversources'];
		
		foreach ($sources as $id => &$source) {
			if ($this->locum_config['sourcelimits'][$id] &&
					$this->lookup_count > $this->locum_config['sourcelimits'][$id]) {
				break;
			}
			$source = str_replace("%ISBN%", $isbn, $source);
			if (fopen($source, "rb")) {
				list($width, $height) = self::getjpegsize($source);
				if ($width > 1) {
					$images[$width] = $id;
				}
			}
		}
		
		// return largest image (or NULL if none found)
		ksort($images);
		$largest_id = end($images);
		$this->sources_count[$largest_id]++;
		return $sources[$largest_id];
	}
	
	public function get_status($bib) {
		$locumclient = new locum_client;
		$status = $locumclient->get_item_status($bib);
		return $status;
	}
	
	/**
	 * create_covercache(): processes the image given by the $image_url into
	 * different sizes, writes them to disk
	 */
	private function create_covercache($bnum, $image_url) {
		$success = FALSE;
		$allowed_widths = $this->locum_config['cover_widths'];
		
		list($width, $height) = self::getjpegsize($image_url);
    if ($image = imagecreatefromjpeg($image_url)) {
			foreach($allowed_widths as $new_width) {
				$new_height = ($new_width / $width) * $height;
				$new_image = imagecreatetruecolor($new_width,$new_height);
				imagecopyresampled($new_image, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
				imagejpeg($new_image, "/mnt/covers/{$bnum}_{$new_width}.jpg", 85);
				imagedestroy($new_image);
			}
			$success = TRUE;
		}
		return $success;
	}
	
	/**
	 * Blatently stolen from http://www.php.net/manual/en/function.getimagesize.php#88793
	 *
	 * "As noted below, getimagesize will download the entire image before it checks for
	 * the requested information. This is extremely slow on large images that are accessed
	 * remotely. Since the width/height is in the first few bytes of the file, there is
	 * no need to download the entire file. I wrote a function to get the size of a JPEG
	 * by streaming bytes until the proper data is found to report the width and height"
	 */
  private function getjpegsize($img_loc) {
    if ($handle = fopen($img_loc, "rb")) {
			$new_block = NULL;
			if(!feof($handle)) {
				$new_block = fread($handle, 32);
				$i = 0;
				if($new_block[$i]=="\xFF" && $new_block[$i+1]=="\xD8" && $new_block[$i+2]=="\xFF" && $new_block[$i+3]=="\xE0") {
					$i += 4;
					if($new_block[$i+2]=="\x4A" && $new_block[$i+3]=="\x46" && $new_block[$i+4]=="\x49" && $new_block[$i+5]=="\x46" && $new_block[$i+6]=="\x00") {
						// Read block size and skip ahead to begin cycling through blocks in search of SOF marker
						$block_size = unpack("H*", $new_block[$i] . $new_block[$i+1]);
						$block_size = hexdec($block_size[1]);
						while(!feof($handle)) {
							$i += $block_size;
							$new_block .= fread($handle, $block_size);
							if($new_block[$i]=="\xFF") {
								// New block detected, check for SOF marker
								$sof_marker = array("\xC0", "\xC1", "\xC2", "\xC3", "\xC5", "\xC6", "\xC7", "\xC8", "\xC9", "\xCA", "\xCB", "\xCD", "\xCE", "\xCF");
								if(in_array($new_block[$i+1], $sof_marker)) {
									// SOF marker detected. Width and height information is contained in bytes 4-7 after this byte.
									$size_data = $new_block[$i+2] . $new_block[$i+3] . $new_block[$i+4] . $new_block[$i+5] . $new_block[$i+6] . $new_block[$i+7] . $new_block[$i+8];
									$unpacked = unpack("H*", $size_data);
									$unpacked = $unpacked[1];
									$height = hexdec($unpacked[6] . $unpacked[7] . $unpacked[8] . $unpacked[9]);
									$width = hexdec($unpacked[10] . $unpacked[11] . $unpacked[12] . $unpacked[13]);
									return array($width, $height);
								} else {
									// Skip block marker and read block size
									$i += 2;
									$block_size = unpack("H*", $new_block[$i] . $new_block[$i+1]);
									$block_size = hexdec($block_size[1]);
								}
							} else {
								return FALSE;
							}
						}
					}
				}
			}
		}
		return FALSE;
	}
}
