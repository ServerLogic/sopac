<?php
/*
 *
 * This template is used when locum returns no hits for a particular search.
 *
 */
?>
<div class="hitlist-nohits">
	<?php if ($locum_result['suggestion']) { ?>
		<div class="hitlist-suggestions">
			Did you mean <i><?php print suggestion_link($locum_result); ?></i> ?
		</div>
		<br />
	<?php } ?>
	» Sorry, your search produced no results. Try this search <a href="http://elibrary.mel.org/search/X<?php echo $locum_result['searchterm']; ?>">at other Michigan libraries</a>.
</div>
