$(document).ready(function(){
	$("#facet").treeview({
		animated: "fast",
		control:"#sidetreecontrol",
		persist: "location"
	});
});

