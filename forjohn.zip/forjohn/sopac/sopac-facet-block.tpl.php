<?php

$uri = $_GET['q'];
$getvars = sopac_parse_get_vars();

?>
<div id="container">
	<div id="sidetreecontrol"><a href="?#">Collapse All</a> | <a href="?#">Expand All</a></div>
	<ul id="facet" class="treeview">
<?php

$mat_count = count($locum_result[facets][mat]);
$search_formats = is_array($getvars[search_format]) ? $getvars[search_format] : array();
if ($mat_count) {
	if (!is_array($getvars[search_format]) || strtolower($_GET[search_format]) == 'all') { 
		$li_prop = ' class="closed"'; 
	} else { 
		$li_prop = NULL; 
	}
	print "<li$li_prop><span class=\"folder\">by Media</span> <small>($mat_count)</small><ul>\n";
	foreach ($locum_result[facets][mat] as $mat_code => $mat_code_count) {
		if (in_array($mat_code, $search_formats)) {
			print '<li id="tree-kid" class="facet-item-selected"><strong>» ' . $locum_config[formats][$mat_code] . "</strong></li>\n";
		} else {
			$getvars_tmp = $getvars;
			if ($getvars_tmp[search_format][0] == 'all') { unset($getvars_tmp[search_format][0]); }
			$getvars_tmp[search_format][] = $mat_code;
			if (isset($getvars_tmp[page])) { $getvars_tmp[page] = ''; }
			$link = l($locum_config['formats'][$mat_code], $uri, array('query' => sopac_make_pagevars(sopac_parse_get_vars($getvars_tmp)))); 
			print '<li id="tree-kid">» ' . $link . ' <small>(' . $mat_code_count . ")</small></li>\n";
			unset($getvars_tmp);
		}
	}
	print "</ul></li>\n";
}

$avail_count = count($locum_result['facets']['avail']);
if ($avail_count) {
	if (empty($getvars['limit_avail'])) {
		$li_prop = ' class="closed"';
	}
	print "<li$li_prop><span class=\"folder\">by Availability</span> <small>($avail_count)</small><ul>\n";
	foreach ($locum_result['facets']['avail'] as $loc_code => $avail_count_indv) {
		if ($locum_config['locations'][$loc_code]) {
			$loc_name = $locum_config['locations'][$loc_code];
		} else if ($loc_code == 'any') {
			$loc_name = "Any Location";
		} else {
			$loc_name = $loc_code;
		}
		if ($loc_code == $getvars['limit_avail']) {
			print '<li id="tree-kid" class="facet-item-selected"><strong>» ' . $loc_name . "</strong></li>\n";
		} else {
			$getvars_tmp = $getvars;
			$getvars_tmp['limit_avail'] = urlencode($loc_code);
			if (isset($getvars_tmp['page'])) { $getvars_tmp['page'] = ''; }
			$link = l($loc_name, $uri, array('query' => sopac_make_pagevars(sopac_parse_get_vars($getvars_tmp)))); 
			print '<li id="tree-kid">» ' . $link . ' <small>(' . $avail_count_indv . ")</small></li>\n";
			unset($getvars_tmp);
		}
	}
	print "</ul></li>\n";
}

$avail_count = count($locum_result['facets']['ages']);
if ($avail_count) {
	if (empty($getvars['age'])) {
		$li_prop = ' class="closed"';
	}
	print "<li$li_prop><span class=\"folder\">by Age</span> <small>($avail_count)</small><ul>\n";
	foreach ($locum_result['facets']['ages'] as $age_code => $age_count_indv) {
		if ($locum_config['ages'][$age_code]) {
			$age_name = $locum_config['ages'][$age_code];
		} else {
			$age_name = $age_code;
		}
		if ($age_code == $getvars['age']) {
			print '<li id="tree-kid" class="facet-item-selected"><strong>» ' . $age_name . "</strong></li>\n";
		} else {
			$getvars_tmp = $getvars;
			$getvars_tmp['age'] = urlencode($age_code);
			if (isset($getvars_tmp[page])) { $getvars_tmp[page] = ''; }
			$link = l($age_name, $uri, array('query' => sopac_make_pagevars(sopac_parse_get_vars($getvars_tmp)))); 
			print '<li id="tree-kid">» ' . $link . ' <small>(' . $age_count_indv . ")</small></li>\n";
			unset($getvars_tmp);
		}
	}
	print "</ul></li>\n";
}

$facet_series = is_array($getvars[facet_series]) ? $getvars[facet_series] : array();
if (count($locum_result[facets][series])) {
	foreach ($locum_result[facets][series] as $series => $series_count) {
		$series = trim($series);
		if ($split_pos = max(strpos($series, ";"), strpos($series, ":"), strpos($series, "."), 0)) {
			$series = trim(substr($series, 0, $split_pos));
		}
		$series_result[$series] += $series_count;
	}
	// weed out those with only one result
	foreach ($series_result as $name => $count) {
		if ($count == 1) {
			unset($series_result[$name]);
		}
	}
	$series_count = count($series_result);
	if ($series_count) {
		if (!is_array($getvars[facet_series])) {
			$li_prop = ' class="closed"';
		}
		print "<li$li_prop><span class=\"folder\">by Series</span> <small>($series_count)</small><ul>\n";
		foreach ($series_result as $series => $series_name_count) {
			if (in_array($series, $facet_series)) {
				print '<li id="tree-kid" class="facet-item-selected"><strong>» ' . $series . "</strong></li>\n";
			} else {
				$getvars_tmp = $getvars;
				$getvars_tmp['facet_series'][] = $series;
				$getvars_tmp['page'] = '';
				$getvars_tmp['q'] = '';
				$link = l($series, $uri, array('query' => sopac_make_pagevars(sopac_parse_get_vars($getvars_tmp)))); 
				print '<li id="tree-kid">» ' . $link . ' <small>(' . $series_name_count . ")</small></li>\n";
				unset($getvars_tmp);
			}
		}
		print "</ul></li>\n";
	}
}

$facet_year = is_array($getvars[facet_year]) ? $getvars[facet_year] : array();
$year_count = count($locum_result[facets][pub_year]);
if ($year_count) {
	if (!is_array($getvars[facet_year])) { $li_prop = ' class="closed"'; } else { $li_prop = NULL; }
	print "<li$li_prop><span class=\"folder\">by Decade</span> <small>($year_count)</small><ul>\n";
	foreach ($locum_result[facets][pub_year] as $year => $pub_year_count) {
		if (in_array($year, $facet_year)) {
			print '<li id="tree-kid" class="facet-item-selected"><strong>» ' . $year . "-" . ($year+9) . "</strong></li>\n";
		} else if ($year <= date('Y')) { // 'cuz catalogers are so infallable.. *cough*
			$getvars_tmp = $getvars;
			$getvars_tmp[facet_year][] = urlencode($year);
			if (isset($getvars_tmp[page])) { $getvars_tmp[page] = ''; }
			$link = l($year . '-' . ($year+9), $uri, array('query' => sopac_make_pagevars(sopac_parse_get_vars($getvars_tmp)))); 
			print '<li id="tree-kid">» ' . $link . ' <small>(' . $pub_year_count . ")</small></li>\n";
			unset($getvars_tmp);
		}
	}
	print "</ul></li>\n";
}

$facet_lang = is_array($getvars[facet_lang]) ? $getvars[facet_lang] : array();
$lang_count = count($locum_result[facets][lang]);
if ($lang_count) {
	if (!is_array($getvars[facet_lang])) { $li_prop = ' class="closed"'; } else { $li_prop = NULL; }
	print "<li$li_prop><span class=\"folder\">by Language</span> <small>($lang_count)</small><ul>\n";
	foreach ($locum_result[facets][lang] as $lang => $lang_code_count) {
		if (in_array($lang, $facet_lang)) {
			print '<li id="tree-kid" class="facet-item-selected"><strong>» ' . $locum_config[language][$lang] . "</strong></li>\n";
		} else {
			$getvars_tmp = $getvars;
			$getvars_tmp[facet_lang][] = urlencode($lang);
			if (isset($getvars_tmp[page])) { $getvars_tmp[page] = ''; }
			$link = l($locum_config['language'][$lang], $uri, array('query' => sopac_make_pagevars(sopac_parse_get_vars($getvars_tmp)))); 
			print '<li id="tree-kid">» ' . $link . ' <small>(' . $lang_code_count . ")</small></li>\n";
			unset($getvars_tmp);
		}
	}
	print "</ul></li>\n";
}
?>				
		</ul>
</div>
