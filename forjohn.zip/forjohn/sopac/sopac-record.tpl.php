<?php
/*
 * Item record display template
 */
$url_prefix = variable_get('sopac_url_prefix', 'cat/seek');
$new_author_str = sopac_author_format($item[author], $item[addl_author]);
$dl_mat_codes = in_array($item[mat_code], $locum->csv_parser($locum_config[format_special][download]));
$no_avail_mat_codes = in_array($item[mat_code], $locum->csv_parser($locum_config[format_special][skip_avail]));
$location_label = $item[loc_code] || ($item[loc_code] != 'none') ? $locum_config[locations][$item[loc_code]] : '';
?>
<?php if (sopac_prev_search_url(TRUE)){ ?>
<p><a href="<?php echo sopac_prev_search_url(); ?>">&#171; Return to your search</a></p>
<?php }	?>
<!-- begin item record -->
<div id="itemrecord">
<div class="item-left">
<?php echo $cover_img; ?>
<ul>
<?php
$series = trim($item[series]);
		if ($split_pos = max(strpos($series, ";"), strpos($series, ":"), strpos($series, "."), 0)) {
			$series = trim(substr($series, 0, $split_pos));
		}
if ($item[pub_info]) { print '<li><b>Published:</b> ' . $item[pub_info] . '</li>';  }
if ($item[pub_year]) { print '<li><b>Year Published:</b> ' . $item[pub_year] . '</li>';  }
if ($item[series]) { print '<li><b>Series:</b> <a href="/' . 
                     $url_prefix . '/search/series/' . urlencode($series) . '">' . $item[series] . '</a></li>';  }
if ($item[edition]) { print '<li><b>Edition:</b> ' . $item[edition] . '</li>';  }
if ($item[descr]) { print '<li><b>Description:</b> ' . nl2br($item[descr]) . '</li>';  }
if ($item[stdnum]) { print '<li><b>ISBN/Standard #:</b>' . $item[stdnum] . '</li>';  }
if ($item[lang]) { print '<li><b>Language:</b> ' . $locum_config[language][$item[lang]] . '</li>';  }
if ($item[mat_code]) { print '<li><b>Format:</b> ' . $locum_config[formats][$item[mat_code]] . '</li>';  }
?>
</ul>
<?php if ($item[addl_author]) { ?>
<h3>Additional Authors</h3>
<ul>
<?php	$addl_author_arr = unserialize($item[addl_author]);
		foreach ($addl_author_arr as $addl_author) {
			$addl_author_link = '/' . $url_prefix . '/search/author/%22' . urlencode($addl_author) .'%22';
?>
<li><a href="<?php echo $addl_author_link; ?>"><?php echo $addl_author; ?></a></li>
<?php } ?>					
</ul>
<?php } if ($item[subjects]) { ?>
<h3>Subjects</h3>
<ul>
<?php
		$subj_arr = unserialize($item[subjects]);
		if (is_array($subj_arr)) {
		foreach ($subj_arr as $subj) {
			$subjurl = '/' . $url_prefix . '/search/subject/%22' . urlencode($subj) . '%22';
?>
<li><a href="<?php echo $subjurl; ?>"><?php echo $subj; ?></a></li>			
<?php } } ?>
</ul>
<h3>Tags</h3>
<?php 
$block = module_invoke('sopac','block','view',4);
print $block['content'];
?>
</div>

<?php }
if($item_status['total'] == 0 && $item_status['holds'] > 0) {
	$class = "holds";
	$reqtext = "There are no copies available. " . $item_status['holds'] . " request" .
	($item_status['holds'] == 1 ? '' : 's') . " on " . count($item_status['items']) . " copies";
}
else if ($item_status['total'] == 0) {
	$class = "first";
	$reqtext = "There are no copies available.";
}
else if($item_status['holds'] > 0) {
	$class = "holds";
	$reqtext = "There are currently $item_status[total] available and " . $item_status['holds'] . " request" . ($item_status['holds'] == 1 ? '' : 's') . " on " . count($item_status['items']) . " copies";
}
else {
	$class = "avail";
	$reqtext = "There are currently $item_status[total] available.";
}
?>
<div id="item-right">
<h1><?php drupal_set_title(ucwords($item[title])); print ucwords($item[title]); ?><?php if ($item[title_medium]) { print " $item[title_medium]"; } ?></h1>
<?php if ($item[author]) { 
	$authorurl = '/' . $url_prefix . '/search/author/%22' . $new_author_str .'%22';
//	$bread = drupal_get_breadcrumb();
//	print_r($bread);
?>
<h3>by <a href="<?php echo $authorurl; ?>"><?php echo $new_author_str; ?></a></h3>
<?php } ?>
<?php if (!in_array($item[loc_code], $no_circ)) { ?>
<div id="item-request" class="<?php echo $class; ?>">
<p><?php echo sopac_put_request_link($item['bnum'],1,0,$locum_config[formats][$item[mat_code]]); ?></p>
<h3><?php echo $reqtext; ?></h3>
</div>
<?php } ?>
<div class="item-avail-disp">
<h2>Where To Find It</h2>
<?php if ($item_status['avail_details']) {
				?><p>Available Copies: <strong><?php print $item_status['avail_details']; ?></strong></p><?php
			} if ($item_status['call_nums']) { 
				?><p>Call number: <strong><?php print implode(", ", $item_status['call_nums']); ?></strong></p><?php
			} ?>

<?php if (count($item_status['items']) && !$no_avail_mat_codes) {
	?><fieldset class="collapsible collapsed"><legend>Show All Copies (<?php print count($item_status['items']); ?>)</legend><?php
        drupal_add_js('misc/collapse.js');
        print theme('table', array("Location", "Call Number", "Item Status"), $item_status['items']);
	?></fieldset><?php
	} else {
		if (!$no_avail_mat_codes) { print '<p>No copies found.</p>'; }
	}
	if (count($item_status['orders'])) { ?>
<p><?php print implode("</p><p>", $item_status['orders']); ?></p>
<?php } ?>
</div>
<?php if($item[tracks]) { ?>
<div id="item-samples">
<h2>Tracks</h2>
<ul class="samples">
<?php foreach($item[tracks] as $track => $info) { ?>
<li><a href="http://media.aadl.org/cdsamples/<?php echo $item[trackupc][upc]; ?>/<?php echo $item[trackupc][upc]; ?>.<?php echo ltrim($info[track],"0"); ?>.mp3"><?php echo $info['track']; ?>. <?php echo $info['name']; ?></a></li>
<?php } ?>
</ul>
</div>
<?php } ?>
<?php
		$note_arr = unserialize($item[notes]);
		if (is_array($note_arr)) {
?>
<div id="item-notes">
<h2>Additional Details</h2>
<?php foreach($note_arr as $note) { ?>
<p><?php echo $note; ?></p>
<?php } ?>
</div>
<?php } ?>
<div id="item-reviews">
<h2>Community Reviews</h2>
<?php if (variable_get('sopac_social_enable', 1)) { print theme_sopac_get_rating_stars($item[bnum]); } ?>
<?php
if (count($rev_arr)) {
	foreach ($rev_arr as $rev_item) {
?>
<div class="hreview">
	<h3 class="summary"><a href="/review/view/<?php echo $rev_item[rev_id]; ?>" class="fn url"><?php echo $rev_item[rev_title];?></a></h3>
	<?php if ($rev_item[uid]) { $rev_user = user_load(array('uid' => $rev_item[uid])); ?>
		<p class="review-byline">submitted by <span class="review-author"><a href="/review/user/<?php echo $rev_item[uid]; ?>"><?php echo $rev_user->name; ?></a> on <abbr class="dtreviewed" title="<?php echo date("c", $rev_item[timestamp]);?>"><?php echo date("F j, Y, g:i a", $rev_item[timestamp]); ?></abbr></span> <?php if ($user->uid == $rev_item[uid]) { ?>[ <a title="Delete this review" href="/review/delete/<?php echo $rev_item[rev_id]; ?>?ref=<?php echo urlencode($_SERVER[REQUEST_URI]); ?>">delete</a> ] [ <a title="Edit this review" href="/review/edit/'<?php echo $rev_item[rev_id]; ?>?ref=<?php echo urlencode($_SERVER[REQUEST_URI]); ?>">edit</a> ]
	<?php } ?></p><?php } ?>
		<div class="review-body description"><?php echo nl2br($rev_item[rev_body]); ?></div></div>
<?php } } else {
	print $no_rev_msg;
}
print $rev_form;
?>
</div>

</div>

<!-- end item record -->
