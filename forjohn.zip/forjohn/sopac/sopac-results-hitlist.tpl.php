<?php
/*
 * Theme template for SOPAC hitlist
 *
 */

// Prep some stuff here

$new_author_str = sopac_author_format($locum_result[author], $locum_result[addl_author]);
$url_prefix = variable_get('sopac_url_prefix', 'cat/seek');
?>
<div class="hitlist-item">
<table>
	<tr>
	<td class="hitlist-number" width="7%"><?php print $result_num; ?></td>
	<td width="13%" valign="top"><?php print $cover_img; ?></td>
	<td width="50%" valign="top">
		<ul class="hitlist-info">
			<li class="hitlist-title">
				<strong><?php print l($locum_result[title], $url_prefix . '/record/' . $locum_result[bnum]) ;?></strong>
				<?php if ($locum_result[title_medium]) { print " $locum_result[title_medium]"; } ?>
			</li>
			<li>
			<?php print l($new_author_str, $url_prefix . '/search/author/"' . urlencode($new_author_str) .'"'); ?>
			</li>
			<li><?php print $locum_result[pub_info]; ?></li>
			<?php if ($locum_result['sort'] == 'catalog_newest') { ?><li>Added on <?php print $locum_result['bib_created']; ?></li><?php } ?>
			<?php if ($locum_result['availability']['call_nums']) { 
				?><li>Call number: <strong><?php print implode(", ", $locum_result['availability']['call_nums']); ?></strong></li><?php
			} else if (count($locum_result[avail_details])) {
				?><li>Call number: <strong><?php print key($locum_result[avail_details]); ?></strong></li><?php
			} ?>
			<br />
			<li>
			<?php if ($locum_result[copies]) {
				print $locum_result[copies] . ($locum_result[copies] == '1' ? " copy" : " copies") . " available at " . $locum_result[avail_details].".";
				if ($locum_result['availability']['holds']) {
					print " ".$locum_result['availability']['holds'] . " request" .
								($locum_result['availability']['holds'] == 1 ? '' : 's') . " on " . count($locum_result['availability']['items']) . " items.";
				}
			} else {
				print "No copies available. ";
				if ($locum_result['availability']['holds']) {
					print $locum_result['availability']['holds'] . " request" .
								($locum_result['availability']['holds'] == 1 ? '' : 's') . " on " . count($locum_result['availability']['items']) . " items.";
				}
			}
			?>
			</li>
			
			<?php 
			if (!in_array($locum_result[loc_code], $no_circ)) {
				print '<li class="item-request"><strong>» ' . sopac_put_request_link($locum_result['bnum'],$locum_result[copies],0,$locum_config[formats][$locum_result[mat_code]]) . '</strong></li>';
			}
			?>
		</ul>
	</td>
	<td width="50%" valign="top">
	<ul class="hitlist-info">
	<?php if($locum_result['syndetics']) { ?>
	<li class="hitlist-title">Reviews and Summaries</li>
	<?php
		print $locum_result['syndetics'];
	 } ?>
	</ul>
	</td>
	<td width="15%">
	<ul class="hitlist-format-icon">
		<li><img src="<?php print '/' . drupal_get_path('module', 'sopac') . '/images/' . $locum_result[mat_code] . '.gif' ?>"></li>
		<li style="margin-top: -2px;"><?php print wordwrap($locum_config[formats][$locum_result[mat_code]], 8, '<br />'); ?></li>
	</ul>

	</td>

	</tr>

</table>
</div>
