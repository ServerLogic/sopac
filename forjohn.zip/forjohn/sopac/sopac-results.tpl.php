<?php
/*
 * Hitlist Page template
 */

// Set some stuff up here

$getvars = sopac_parse_get_vars();
$sorted_by = $getvars['sort'];
$sortopts = array(
		'' => 'Relevance',
		'atoz' => 'Alphabetical A to Z',
		'ztoa' => 'Alphabetical Z to A',
		'catalog_newest' => 'Just Added',
		'newest' => 'Pub date: Newest',
		'oldest' => 'Pub date: Oldest',
		'author' => 'Alphabetically by Author',
		'top_rated' => 'Top Rated Items',
		'popular_week' => 'Most Popular this Week',
		'popular_month' => 'Most Popular this Month',
		'popular_year' => 'Most Popular this Year',
		'popular_total' => 'All Time Most Popular',
	);
$url_prefix = variable_get('sopac_url_prefix', 'cat/seek');
$uri = $_GET['q'];
?>
<?php if ($result_info[num_results] > 0) { ?>
<div class="hitlist-top-bar">

<?php if ($locum_result[suggestion]) { ?>
<div class="hitlist-suggestions">
	Did you mean <i><?php print suggestion_link($locum_result); ?></i> ?
</div>
<br />
<?php } ?>
	<span class="hitlist-range">
		<strong>»</strong> Showing results <?php print $result_info[hit_lowest] . ' to ' . $result_info[hit_highest] . ' of ' . $result_info[num_results]; ?>
	</span>
	<span class="hitlist-sorter">
		<script>
		jQuery(document).ready(function() {$('#sortlist').change(function(){ location.href = $(this).val();});});
		</script>
		Sort by: <select name="sort" id="sortlist">
		<?php foreach($sortopts as $key => $value) { ?>
		<option value="<?php echo url($_GET['q'], array('query' => sopac_make_pagevars(sopac_parse_get_vars(array('page' => '', 'limit' => '', 'sort' => $key))))) ?>" <?php if($sorted_by == $key) echo 'selected'; ?>><?php echo $value; ?></option>
		<?php } ?>
		</select>
	</span>
</div>
<br />
<div class="hitlist-pager">
<?php print $hitlist_pager; ?>
</div>
<?php } ?>

<div class="hitlist-content">
<?php print $hitlist_content; ?>
</div>
<div class="hitlist-pager">
<?php print $hitlist_pager; ?>
</div>
<p class="mel">Try this search <a href="http://elibrary.mel.org/search/X<?php echo $locum_result['searchterm']; ?>">at other Michigan libraries</a>.</p>