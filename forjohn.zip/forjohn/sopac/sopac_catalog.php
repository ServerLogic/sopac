<?php
/**
 * SOPAC is The Social OPAC: a Drupal module that serves as a wholly integrated web OPAC for the Drupal CMS
 * This file contains the Drupal include functions for all the catalog functions within SOPAC
 * This file is called via hook_menu
 *
 * @package SOPAC
 * @version 2.0
 * @author John Blyberg
 */



/**
 * Prepares and returns the HTML for the SOPAC search page/hit list.
 * Uses the following templates: sopac_results.tpl.php, sopac_results_hitlist.tpl.php, sopac_results_nohits.tpl.php
 *
 * @return string SOPAC catalog search HTML
 */
function sopac_catalog_search() {
	global $pager_page_array, $pager_total, $locum_results_all, $locum_cfg;
	
	// Load Required JS libraries
	drupal_add_js(drupal_get_path('module', 'sopac') .'/js/jquery.treeview.js');
	drupal_add_js(drupal_get_path('module', 'sopac') .'/js/facet-browser.js');
	//drupal_add_js(drupal_get_path('module', 'sopac') .'/js/ui.stars.js');
	drupal_add_js(drupal_get_path('module', 'sopac') .'/js/thickbox-compressed.js');

	$getvars = sopac_parse_get_vars();
	$locum = new locum_client;
	$locum_cfg = $locum->locum_config;
	$no_circ = $locum->csv_parser($locum_cfg[location_limits][no_request]);
	$valid_search_types = array('title', 'author', 'keyword', 'subject', 'series', 'callnum', 'tags', 'reviews'); // TODO handle this more dynamically
	$actions = sopac_parse_uri();

	$sort = $getvars['sort'];
	$format = $getvars['search_format'];
	$location = $getvars['location'];
	$limit_avail = $getvars['limit_avail'];
	$pager_page_array = explode(',', $getvars['page']);

	// If there is a proper search query, we get that data here.
	if (in_array($actions[1], $valid_search_types)) {
		$valid_search = TRUE;
		$_SESSION[search_url] = $_SERVER[REQUEST_URI];
		if ($addl_search_args[limit]) { 
			$limit = $addl_search_args[limit]; 
		} else { 
			$limit = variable_get('sopac_results_per_page', 20);
		}

		// Initialize the pager if need be
		if ($pager_page_array[0]) { $page = $pager_page_array[0] + 1; } else { $page = 1; }
		$page_offset = $limit * ($page - 1);

		// Grab the faceted search arguments from the URL
		$facet_args = array();
		if (count($getvars[facet_series])) { $facet_args[facet_series] = $getvars[facet_series]; }
		if (count($getvars[facet_lang])) { $facet_args[facet_lang] = $getvars[facet_lang]; }
		if (count($getvars[facet_year])) { $facet_args[facet_year] = $getvars[facet_year]; }
		if ($getvars['age']) { $facet_args['age'] = $getvars['age']; }

		// Get the search results from Locum
		$locum_results_all = $locum->search($actions[1], utf8_urldecode($actions[2]), $limit, $page_offset, $sort, $format, $location, $facet_args, FALSE, $limit_avail);
		drupal_set_title("Search for ".utf8_urldecode($actions[2]));
		$num_results = $locum_results_all[num_hits];
		$result_info[num_results] = $num_results;
		$result_info[hit_lowest] = $page_offset + 1;
		if (($page_offset + $limit) < $num_results) { 
			$result_info[hit_highest] = $page_offset + $limit; 
		} else { 
			$result_info[hit_highest] = $num_results; 
		}
	}

	// Construct the search form
	$search_form_cfg = variable_get('sopac_search_form_cfg', 'both');
	$search_form = sopac_search_form($search_form_cfg);
	$locum_results_all['searchterm'] = urlencode($actions[2]);
	// If we get results back, we begin creating the hitlist
	if ($locum_results_all[results]) {
		// We need to determine how many result pages there are.
		$pager_total[0] = ceil($num_results / $limit);
		$hitlist = '';
		$hitnum = $page_offset + 1;
		if($locum_results_all['changed'] == 'yes'){drupal_set_message("We did not find any results for all of your keywords. Below are results that match some of them.");}
		foreach ($locum_results_all[results] as $locum_result) {
			// Format stdnum as best we can
			if (preg_match('/ /', $locum_result[stdnum])) {
				$stdnum_arr = explode(' ', $locum_result[stdnum]);
				$stdnum = $stdnum_arr[0];
				$locum_result[stdnum] = $stdnum;
			} else {
				$stdnum = $locum_result[stdnum];
			}
			if($syndetics = $locum->get_syndetics($stdnum)) {
				$locum_result['syndetics'] = $syndetics;
				}
			if ($locum_result[copies] = intval($locum_result['availability']['total'])) {
				$locations = array();
				foreach($locum_result['availability']['locations'] as $loc_code => $details) {
					$locations[] = $locum->locum_config['locations'][$loc_code];
				}
				$locum_result[avail_details] = implode(", ", $locations);
			}

			$cover_img_url = $locum_result[cover_img];
			if (!$cover_img_url) {
				$cover_img_url = '/' . drupal_get_path('module', 'sopac') . '/images/nocover.png';
			}
			$locum_result['sort'] = $sort;
			$result_body .= theme('sopac_results_hitlist', $hitnum, $cover_img_url, $locum_result, $locum_cfg, $no_circ);
			$hitnum++;
		}
		$hitlist_pager = theme('pager', NULL, $limit, 0, NULL, 6);
	} else if ($valid_search) {
		$result_body .= theme('sopac_results_nohits', $locum_results_all, $locum->locum_config);
	}
	// Pull it all together into the search page template
	$result_page = $search_form . theme('sopac_results', $result_info, $hitlist_pager, $result_body, $locum_results_all, $locum->locum_config);

	return '<p>'. t($result_page) .'</p>';

}

function sopac_advanced_search() {
	$search_form_cfg = variable_get('sopac_search_form_cfg', 'advanced');
	$search_form = sopac_search_form('advanced');
	return t($search_form);
}
/**
 * Prepares and returns the HTML for an item record.
 * Uses the following templates: sopac_record.tpl.php
 *
 * @return string Item record HTML
 */
function sopac_bib_record() {
	global $user;
	drupal_add_js(drupal_get_path('module', 'sopac') .'/js/thickbox-compressed.js');
	drupal_add_js(drupal_get_path('module', 'sopac') .'/js/soundmanager2-nodebug-jsmin.js');
	drupal_add_js(drupal_get_path('module', 'sopac') .'/js/inlineplayer.js');
	drupal_add_css(drupal_get_path('module', 'sopac') .'/thickbox.css');
	$locum = new locum_client;
	$insurge = new insurge_client;
	$actions = sopac_parse_uri();
	$bnum = $actions[1];
	
	// Load social function
	require_once('sopac_social.php');
	$bnum_arr[] = $bnum;
	$reviews = $insurge->get_reviews(NULL, $bnum_arr, NULL);
	$i = 0;
	foreach ($reviews[reviews] as $insurge_review) {
				$rev_arr[$i][rev_id] = $insurge_review[rev_id];
				$rev_arr[$i][bnum] = $insurge_review[bnum];
				if ($insurge_review[uid]) { $rev_arr[$i][uid] = $insurge_review[uid]; }
				$rev_arr[$i][timestamp] = $insurge_review[rev_create_date];
				$rev_arr[$i][rev_title] = $insurge_review[rev_title];
				$rev_arr[$i][rev_body] = $insurge_review[rev_body];
				$i++;
	}
	$no_circ = $locum->csv_parser($locum->locum_config[location_limits][no_request]);
	$item = $locum->get_bib_item($bnum);
	$item_status = $locum->get_availability($bnum, TRUE);
	if (intval($item_status['total'])) {
		$locations = array();
		foreach($item_status['locations'] as $loc_code => $details) {
			foreach ($details as $age => $count) {
				$locations[] = $locum->locum_config['locations'][$loc_code] . " " . ucfirst($age) . " (" . $count . ")";
			}
		}
		$item_status['avail_details'] = implode(", ", $locations);
	}
	if($item[mat_code] == 'j') {
		$item[tracks] = $locum->get_cd_tracks($bnum);
		$item[trackupc] = $locum->get_upc($bnum); 
	}
	if ($item[bnum]) {
				if (!$insurge->check_reviewed($user->uid, $item[bnum]) && $user->uid) {
					$rev_form = drupal_get_form('sopac_review_form', $item[bnum]);
				} else if (!$user->uid) {
					$rev_form = '<div class="review-login"><a href="/myaccount">Login</a> to write a review</div>';
				}
	}

	if ($item[bnum]) {
		$result_page = theme('sopac_record', $item, $item_status, $locum->locum_config, $no_circ, &$locum, $rev_arr, $rev_form);
	} else {
		$result_page = 'This record does not exist.';
	}

	return t($result_page);
}

/**
 * Formulates and returns the search tracker block HTML.
 * Uses the following templates: sopac_search_block.tpl.php
 *
 * @return string Search tracker block HTML
 */
function sopac_search_block($locum_results_all, $locum_cfg) {
	global $user;

	$getvars = sopac_parse_get_vars();
	$uri = sopac_parse_uri();
	$format = $getvars[search_format];
	$term_arr = explode('?', trim(preg_replace('/\//', ' ', $uri[2])));

	$search[term] = trim($term_arr[0]);
	$search[type] = trim($uri[1]);
	$search[sortby] = $getvars[sort] ? $getvars[sort] : 'Most relevant';
	$search[format] = count($getvars[search_format]) && ($getvars[search_format][0] != 'all') ? $getvars[search_format] : array();
	$search[series] = count($getvars[facet_series]) ? $getvars[facet_series] : array();
	$search[lang] = count($getvars[facet_lang]) ? $getvars[facet_lang] : array();
	$search[year] = count($getvars[facet_year]) ? $getvars[facet_year] : array();

	return theme('sopac_search_block', $search, $locum_results_all, $locum_cfg, $user);

}

/**
 * If nothing is in the author field, we try the addl author field.
 * Oh, and we present first name first.  Like it oughta.
 *
 * @param string $author Author string as presented up from Locum
 * @param string $addl_author_ser Serialized additional author string as presented up from Locum
 * @return string The formatted author string
 */
function sopac_author_format($author, $addl_author_ser) {

	if ($author) {
		$author_arr = explode(',', $author);
		$new_author_str = trim($author_arr[1]) . ' ' . trim($author_arr[0]);
	} else if ($addl_author_ser) {
		$addl_author = unserialize($addl_author_ser);
		if ($addl_author[0]) {
			$author_arr = explode(',', $addl_author[0]);
			$new_author_str = trim($author_arr[1]) . ' ' . trim($author_arr[0]);
		}
	}
	if ($new_author_str) { 
		$new_author_str = ereg_replace("[^A-Za-z '.-]", '', $new_author_str ); 
		$new_author_str = preg_replace('/ - /', ' ', $new_author_str);	
	} else {
		$new_author_str = '';
	}
	return $author;
	//return $new_author_str;
}

/**
 * Create the "Did you mean" link
 *
 * @param array $locum_result Locum result array as passed up from Locum
 * @return string Suggestion link
 */
function suggestion_link($locum_result) {
	return l($locum_result['suggestion'],
					 variable_get('sopac_url_prefix', 'cat/seek') . '/search/' . $locum_result['type'] . '/' . $locum_result['suggestion'],
					 array('query' => sopac_make_pagevars(sopac_parse_get_vars()))
					);
}

/**
 * Takes an array and creates page variable.  It's basically the reverse of sopac_parse_get_vars()
 *
 * @param array Array of variables to formulate
 * @return a query array suitable for use in the l() or url() functions
 */
function sopac_make_pagevars($getvars) {
	if (count($getvars)) {
		foreach ($getvars as $key => &$var) {
			if (is_array($var)) {
				$var = implode('|', $var);
			}
		}
	}
	return $getvars;
}

/**
 * This function will return the appropriate request link based on whether the user is logged in, has a verified card, or not
 * 
 * @return string HTML string for the request link
 */
function sopac_put_request_link($bnum, $avail = 0, $holds = 0, $mattype = "item") {
	global $user;
	profile_load_profile(&$user);

	if ($user->uid) {
		if (sopac_bcode_isverified(&$user)) {
			// User is logged in and has a verified card number
			$path = variable_get('sopac_url_prefix', 'cat/seek') . '/request/' . $bnum;
			if($avail > 0) {
				$link_text = 'Request this '.$mattype;
			}
			if($avail == 0) {
				$link_text = 'Request the next available copy';
			}
		} else if ($user->profile_pref_cardnum) {
			// User is logged in but does not have a verified card number
			$path = 'user/' . $user->uid;
			$link_text = 'Verify your card to request this item';
		} else {
			// User is logged in but does not have a card number.
			$path = 'user/' . $user->uid;
			$link_text = 'Register your card to request this item';
		}
	} else {
		$path = 'user';
		$query = array('destination' => variable_get('sopac_url_prefix', 'cat/seek') . '/record/' . $bnum);
		$link_text = 'Please log in to request this item';
	}

	return l($link_text, $path, array('query' => $query));
}

/**
 * Returns the search URL, only if the user is coming directly from the search page.
 *
 * @return string|bool Search URL or FALSE
 */
function sopac_prev_search_url($override = FALSE) {
	if (!$_SESSION[search_url]) { return FALSE; }
	$referer = substr($_SERVER[HTTP_REFERER], 7 + strlen($_SERVER[HTTP_HOST]));
	$search = $_SESSION[search_url];
	if ((($search == $referer) || $override) && $_SESSION[search_url]) { return $search; } else { return FALSE; }
}

/**
 * Requests a particular item via locum then displays the results of that request
 *
 * @return string Request result
 */
function sopac_request_item() {
	global $user;
	
	$button_txt = 'Request Selected Item';
	profile_load_profile(&$user);
	if ($user->uid && sopac_bcode_isverified(&$user)) {
		
		if ($_POST[sub_type] == $button_txt) {
			if ($_POST[varname]) {
				$varname = $_POST[varname];
			} else {
				$request_error_msg = 'You need to select an item to request.';
			}
		}
		
		$locum = new locum_client;
		$actions = sopac_parse_uri();
		$bnum = $actions[1];
		$pickup_arg = $actions[2] ? $actions[2] : null;
		$stored_pickup_options = variable_get('profile_pickup', array());
		if (!$pickup_arg && count($stored_pickup_options)) {
			$hold_result['choose_location']['options'] = $stored_pickup_options;
		}
		else {
			$pickup_name = $actions[3] ? $actions[3] : null;
			$locum = new locum_client;
			$bib_item = $locum->get_bib_item($bnum);
			$hold_result = $locum->place_hold($user->profile_pref_cardnum, $bnum, $varname, $user->locum_pass, $pickup_arg);
		}
		
		if ($hold_result['success']) {
			// handling multi-branch scenario
			$request_result_msg = t('You have successfully requested a copy of ') . '<span class="req_bib_title"> ' . $bib_item['title'] . '</span>';
			if ($pickup_name) {
				$request_result_msg .= t(' for pickup at ') . $pickup_name;
			}
		}
		// more multibranch
		elseif (is_array($hold_result['choose_location'])) {
			// pickup location
			$form_data = array(
				'options' => $hold_result['choose_location']['options'],
				'bnum' => $bnum,
			);
			$request_result_msg = "<h2>Request Verification</h2><h3>Requesting: $bib_item[title]</h3>".drupal_build_form('sopac_hold_location_form', $form_data);
		}
		else {
			$request_result_msg = t('We were unable to fulfill your request for ') . '<span class="req_bib_title">' . $bib_item['title'] . '</span>';
		}
		
		if ($hold_result['error']) {
			$request_result_msg = $hold_result['error'];
		}
		
		if ($hold_result['selection']  && !$hold_result['success']) {
			$requestable = 0;
			$header = array('',t('Location'),t('Call Number'),t('Status'));
			foreach ($hold_result['selection'] as $selection) {
				$status = $selection['status'];
				if ($selection['varname']) {
					$radio = '<input type="radio" name="varname" value="' . $selection['varname'] . '">';
					$non_circ = NULL;
					$requestable++;
				} else {
					$radio = '';
					$status = '<span class="non_circ_msg">' . $status . '</span>';
				}
				$rows[] = array(
					$radio,
					$selection['location'],
					$selection['callnum'],
					$status,
				);
			}
			if ($requestable) {
				$submit_button = '<input type="submit" name="sub_type" value="' . $button_txt . '">';
				$request_result_msg = t('Please select the item you would like to request.');
			} else {
				$submit_button = NULL;
				$request_result_msg = '';
				$request_error_msg = t('There are no copies of this item available for circulation.');
			}
			if ($submit_button){
				$rows[] = array( 'data' => array(array('data' => $submit_button, 'colspan' => 4)), 'class' => 'req_button' );
			}
			$item_form = '<form method="post">' . theme('table', $header, $rows, array('id' => 'reqlist', 'cellspacing' => '0')) . '</form>';
		}
		
		// TODO - add a tally for top items data recovery
	} else {
		$request_error_msg = t("You must have a valid library card number registered with our system.");
	}
	$result_page = theme('sopac_request', $request_result_msg, $request_error_msg, $item_form, $bnum);
	return '<p>'. t($result_page) .'</p>';
}

function sopac_hold_location_page() {
	$output = drupal_get_form('sopac_hold_location_form');
	return $output;
}

function sopac_hold_location_form($form_data = null) {
	global $user;
	if (isset($form_data['bnum'])) {
		$form_data['storage']['options'] = $form_data['options'];
		$form_data['storage']['bnum'] = $form_data['bnum'];
	}
	$options = $form_data['storage']['options'];
	$form = array();
	$form['#action'] = '/hold/location';
	$form['hold_location'] = array(
		'#type' => 'select',
		'#title' => t('Choose a pickup location'),
		'#options' => $options,
	);
	if (isset($user->profile_pickup)) {
		$options = array_flip($options);
		if (array_key_exists($user->profile_pickup, $options)) {
			$form['hold_location']['#default_value'] = $options[$user->profile_pickup];
		}
	}
	$form['op'] = array(
		'#type' => 'submit',
		'#value' => t('Submit'),
	);
	return $form;
}

function sopac_hold_location_form_submit($form, &$form_state) {
	$location_name = $form['hold_location']['#options'][$form_state['values']['hold_location']];
	//drupal_set_message(t('You chose ' . $location_name));
	$bnum = $form_state['storage']['bnum'];
	unset($form_state['storage']);
	drupal_goto('catalog/request/' . $bnum . '/' . $form_state['values']['hold_location'] . '/' . $location_name);
}


/**
 * Returns the url string to use in the save search link.
 *
 * @return string URL
 */
function sopac_savesearch_url() {
	$search_url = '/' . variable_get('sopac_url_prefix', 'cat/seek') . '/savesearch' . substr($_SERVER[REQUEST_URI], 8 + strlen(variable_get('sopac_url_prefix', 'cat/seek')));
	return $search_url;
}

/**
 * Formulates the basic search form array
 *
 * @return array Drupal search form array
 */
function sopac_basic_catalog_form($form_state) {
	$locum = new locum();
	$locum_cfg = $locum->locum_config;
	$getvars = sopac_parse_get_vars();

	$actions = sopac_parse_uri();
	if ($actions[0] == "search") {
		$search_query = $actions[2];
		$stype_selected = $actions[1] ? 'cat_' . $actions[1] : 'cat_keyword';
	}
	
	$sformats = array('' => 'Everything');
	foreach ($locum_cfg[format_groups] as $sfmt => $sfmt_codes) {
		$sformats[preg_replace('/,[ ]*/', '|', trim($sfmt_codes))] = ucfirst($sfmt);
	}

	$stypes = array(
		'cat_keyword' => 'Keyword',
		'cat_title' => 'Title',
		'cat_author' => 'Author',
		'cat_series' => 'Series',
		'cat_tags' => 'Tags',
		'cat_reviews' => 'Reviews',
		'cat_subject' => 'Subject',
		'cat_callnum' => 'Call Number',
	);

	$sortopts = array(
		'' => 'Relevance',
		'atoz' => 'Alphabetical A to Z',
		'ztoa' => 'Alphabetical Z to A',
		'catalog_newest' => 'Just Added',
		'newest' => 'Pub date: Newest',
		'oldest' => 'Pub date: Oldest',
		'author' => 'Alphabetically by Author',
		'top_rated' => 'Top Rated Items',
		'popular_week' => 'Most Popular this Week',
		'popular_month' => 'Most Popular this Month',
		'popular_year' => 'Most Popular this Year',
		'popular_total' => 'All Time Most Popular',
	);

	// Initialize the form
	$form = array(
		'#attributes' => array('class' => 'search-form'),
		'#validate' => array('sopac_search_catalog_validate'),
		'#submit' => array('sopac_search_catalog_submit'),
	);
	// Start creating the basic search form
	$form['inline'] = array(
		'#prefix' => '<div class="container-inline">',
		'#suffix' => '</div>'
	);
	$form['inline']['search_query'] = array(
		'#type' => 'textfield',
		'#title' => 'Search ',
		'#default_value' => $search_query,
		'#size' => 25,
		'#maxlength' => 255,
	);
	$form['inline']['search_type'] = array(
		'#type' => 'select',
		'#title' => t(' by '),
		'#default_value' => $stype_selected,
		'#options' => $stypes,
	);
	$form['inline']['search_format'] = array(
		'#type' => 'select',
		'#title' => t(' in '),
		'#default_value' => $_GET['search_format'],
		'#selected' => $_GET['search_format'],
		'#options' => $sformats,
	);
	$form['inline']['submit'] = array(
		'#type' => 'submit',
		'#value' => t('Search'),
	);
	$form['inline2'] = array(
		'#prefix' => '<div class="container-inline">',
		'#suffix' => '</div>',
	);
	$form['inline2']['limit'] = array(
		'#type' => 'checkbox',
		'#default_value' => $getvars['limit'],
	);
	$form['inline2']['limit_avail'] = array(
		'#type' => 'select',
		'#title' => 'limit to items available at',
		'#options' => array_merge(array('any' => "Any Location"), $locum_cfg['locations']),
		'#default_value' => $getvars['limit_avail'],
	);
	$form['inline2']['advanced_link'] = array(
		'#value' => l("» Advanced Search", variable_get('sopac_url_prefix', 'cat/seek') . '/advanced'),
	);
	return $form;
}

/**
 * Formulates the advanced search form array
 *
 * @return array Drupal search form array
 */
function sopac_advanced_catalog_form($form_state) {
	$locum = new locum();
	$locum_cfg = $locum->locum_config;
	$getvars = sopac_parse_get_vars();

	$actions = sopac_parse_uri();
	if ($actions[0] == "search") {
		$search_query = $actions[2];
		$stype_selected = $actions[1] ? 'cat_' . $actions[1] : 'cat_keyword';
	}
	
	$sformats = array('' => 'Everything');
	foreach ($locum_cfg[format_groups] as $sfmt => $sfmt_codes) {
		$sformats[preg_replace('/,[ ]*/', '|', trim($sfmt_codes))] = ucfirst($sfmt);
	}

	$stypes = array(
		'cat_keyword' => 'Keyword',
		'cat_title' => 'Title',
		'cat_author' => 'Author',
		'cat_series' => 'Series',
		'cat_tags' => 'Tags',
		'cat_reviews' => 'Reviews',
		'cat_subject' => 'Subject',
		'cat_callnum' => 'Call Number',
		'cat_isn' => 'ISBN or ISSN',
	);

	$sortopts = array(
		'' => 'Relevance',
		'atoz' => 'Alphabetical A to Z',
		'ztoa' => 'Alphabetical Z to A',
		'catalog_newest' => 'Just Added',
		'newest' => 'Pub date: Newest',
		'oldest' => 'Pub date: Oldest',
		'author' => 'Alphabetically by Author',
		'top_rated' => 'Top Rated Items',
		'popular_week' => 'Most Popular this Week',
		'popular_month' => 'Most Popular this Month',
		'popular_year' => 'Most Popular this Year',
		'popular_total' => 'All Time Most Popular',
	);

	// Initialize the form
	$form = array(
		'#attributes' => array('class' => 'search-form'),
		'#validate' => array('sopac_search_catalog_validate'),
		'#submit' => array('sopac_search_catalog_submit'),
	);
	
	$form['search_query'] = array(
		'#type' => 'textfield',
		'#title' => t('Search term or phrase'),
		'#default_value' => $search_query,
		'#size' => 50,
		'#maxlength' => 255,
	);
	
	$form['search_type'] = array(
		'#type' => 'select',
		'#title' => t('Search by'),
		'#default_value' => $stype_selected,
		'#options' => $stypes,
	);
	$form['sort'] = array(
		'#type' => 'select',
		'#title' => t('Sorted by'),
		'#default_value' => '',
		'#options' => $sortopts,
	);
	$form['age_group'] = array(
		'#type' => 'select',
		'#title' => 'in age group',
		'#options' => array('' => "Any Age Group", 'adult' => "Adult", 'teen' => "Teen", 'youth' => "Youth"),
	);
	
	$form['limit'] = array(
		'#prefix' => '<div class="container-inline">',
		'#type' => 'checkbox',
		'#default_value' => $getvars['limit'],
	);
	$form['limit_avail'] = array(
		'#type' => 'select',
		'#title' => 'limit to items available at',
		'#options' => array_merge(array('any' => "Any Location"), $locum_cfg['locations']),
		'#default_value' => $getvars['limit_avail'],
		'#suffix' => "</div>",
	);
	if (count($locum_cfg[collections])) {		
		foreach ($locum_cfg[collections] as $loc_collect_key => $loc_collect_var) {
			$loc_collect[$loc_collect_key] = $loc_collect_key;
		}
		
		$form['collection'] = array(
			'#type' => 'select',
			'#title' => t('In these collections'),
			'#size' => 5,
			'#default_value' => $getvars[collection],
			'#options' => $loc_collect,
			'#multiple' => TRUE,
		);
	}

	asort($locum_cfg[formats]);
	$form['search_format'] = array(
		'#type' => 'select',
		'#title' => t('In these formats'),
		'#size' => 5,
		'#default_value' => $getvars[search_format],
		'#options' => $locum_cfg[formats],
		'#multiple' => TRUE,
	);
	$form['publisher'] = array(
		'#type' => 'textfield',
		'#title' => t('Publisher'),
		'#size' => 20,
		'#maxlength' => 255,
	);
	$form['pub_year_start'] = array(
		'#type' => 'textfield',
		'#title' => t('Published year between'),
		'#size' => 20,
		'#maxlength' => 255,
	);
	$form['pub_year_end'] = array(
		'#type' => 'textfield',
		'#title' => t('and'),
		'#size' => 20,
		'#maxlength' => 255,
	);
	
	$form['submit'] = array(
		'#type' => 'submit',
		'#value' => t('Search'),
	);
	$form['clear'] = array(
		'#name' => 'clear',
		'#type' => 'button',
		'#value' => t('Reset'),
		'#attributes' => array('onclick' => 'this.form.reset(); return false;'),
	);	
	return $form;
}

/**
 * validate on form submission
 */
function sopac_search_catalog_validate($form, &$form_state) {
	if (trim($form_state['values']['search_query']) == '') {
		form_set_error('search_query', t('Please enter a search term to start your search'));
	}
}

/**
 * build a search url based on form submission, handles both basic and advanced search forms
 */
function sopac_search_catalog_submit($form, &$form_state) {
	$locum = new locum();
	$locum_cfg = $locum->locum_config;

	$search_query = trim($form_state['values']['search_query']);
	if (!$search_query) { $search_query = '*'; }
	$search_type = $form_state['values']['search_type'];
	$search_type_arr = explode('_', $search_type);
	if ($search_type_arr[0] == 'cat') {
		$search_type = $search_type_arr[1];
		if ($search_type == 'isn') {
			$search_type = 'keyword';
		}
		$search_fmt = $search_type_arr[2];
		$search_url = variable_get('sopac_url_prefix', 'cat/seek') . '/search/' . $search_type . '/' . $search_query;
		
		// Material / Format types
		if ($search_fmt) {
			if ($search_fmt != 'all') {
				$uris['search_format'] = $locum->csv_parser($locum_cfg[format_groups][$search_fmt], '|');
			}
		} else if ($form_state['values']['search_format']) {
			if (is_array($form_state['values']['search_format'])) { 
				$uris['search_format'] = trim(implode('|', $form_state['values']['search_format']));
			} else {
				$uris['search_format'] = $form_state['values']['search_format'];
			}
		}
		
		// Location selections overrule collection selections and act as 
		// a filter if they are in a selection colection.
		if ($form_state['values']['collection']) {
			$locations = array();
			$uris[collection] = trim(implode('|', $form_state['values']['collection']));
			foreach ($form_state['values']['collection'] as $collection) {
				$collection_arr = $locum->csv_parser($locum_cfg[collections][$collection]);
				if ($form_state['values']['location']) {
					$valid_locs = array_intersect($form_state['values']['location'], $collection_arr);
					if (count($valid_locs)) {
						$locations = array_merge($locations, $valid_locs);
					} else {
						$locations = array_merge($locations, $collection_arr);
					}
				} else {
					$locations = array_merge($locations, $collection_arr);
				}
			}
			if ($form_state['values']['location']) {
				$locations = array_merge($locations, array_diff($form_state['values']['location'], $locations));
			}
		} else if ($form_state['values']['location']) {
			$locations = $form_state['values']['location'];
		}
		if (count($locations)) { $uris['location'] = trim(implode('|', $locations)); }
		
		// Sort variable
		if ($form_state['values']['sort']) { $uris['sort'] = $form_state['values']['sort']; }
		
		// Age Group variable
		if ($form_state['values']['age_group']) { $uris['age'] = $form_state['values']['age_group']; }
		
		// Limit to Available
		if ($form_state['values']['limit']) {
			$uris['limit_avail'] = $form_state['values']['limit_avail'];
		}
		
		// Publisher Search
		if ($form_state['values']['publisher']) {
			$uris['pub'] = trim($form_state['values']['publisher']);
		}
		if ($form_state['values']['pub_year_start'] || $form_state['values']['pub_year_end']) {
			$uris['pub_year'] = trim($form_state['values']['pub_year_start']) . '|' .
													trim($form_state['values']['pub_year_end']);
		}
	} else if ($search_type_arr[0] == 'web') {
		switch ($search_type_arr[1]) {
			case 'local':
				$search_url = 'search/node/' . utf8_urldecode($search_query);
				break;
			case 'google':
				$search_url = 'http://www.google.com/search?hl=en&q=' . utf8_urldecode($search_query);
				break;
		}
	}

	drupal_goto($search_url, $uris);
}